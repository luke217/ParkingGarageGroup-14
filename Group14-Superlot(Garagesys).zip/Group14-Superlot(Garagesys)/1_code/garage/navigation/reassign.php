<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Superlot</title>

    <!-- Bootstrap -->
    <link href="/garage/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	
	
	
	
  </head>

 <body>
 <?php
   session_start();
  include('../connect/dbconnect.php');
  if((!isset($_SESSION['role']))||($_SESSION['role']!='customer')){
	header("location:/garage/index.php");
  }	  

  
   function reassignSpot($dbconnect,$garage_id,$beginTime,$endTime, $price=1){
	 $garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id=".$garage_id));
	 $spots = mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE state=0 AND disable = 0 AND price = ".$price);
	 while($spot = mysqli_fetch_assoc($spots)){
		 
		 if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM reservations 
			WHERE valid=1 AND spot_id=".$spot['spot_id']." AND garage_id=".$garage_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' ))"))){//unavaliable in reservation
			continue;
		}
		else if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers 
			WHERE spot_id=".$spot['spot_id']." AND garage_id=".$garage_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' ))"))){//unavaliable in parkingusers
			continue;
		}
		else{
			return $spot;		
		}
	 }
	 return NULL; 	 
 }
  
  
  ?>
 <div class="container-fluid"style="background-image: url('/garage/img/background.jpg');
                              background-repeat: no-repeat;
                              -webkit-background-size: cover;
                              -moz-background-size: cover;
                              -o-background-size: cover;
                               background-size: cover;
                              margin-right:auto;
                              margin-left:auto;                           
                              height:950px;;
                              opacity: 0.85;
                              filter: alpha(opacity=90);"
                              >
                              


     

      <!-- Main component for a primary marketing message or call to action -->
	  <?php
	  include('../customer/navbar.php');
	  include('../whatsnew.php');
	  ?>
	<div name='login' class="jumbotron" style="opacity: 0.95;
                              filter: alpha(opacity=90);">
	<?php
	if(isset($_POST['plateNum'])&&($_POST['plateNum']!=NULL)){
		$user = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE user_id = ".$_SESSION['user_id']));
		$garage  = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id = ".$user['garage_id']));
		$spot  = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id = ".$user['spot_id']));
		
		if($spot['state']){//if the spot is indeed occupied
			if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE plateNum = '".$_POST['plateNum']."'"))){//if reported vehicle is in the garage
				//first add into the report database
				$d = date('Y-m-d H:i:s');
				$s = mysqli_query($dbconnect,"INSERT INTO reports (user_id,garage_id,plateNum,spot_id,time) 
				VALUES (".$_SESSION['user_id'].",".$garage['garage_id'].",'".$_POST['plateNum']."',".$user['spot_id'].",'".$d."')");
				//var_dump($user);

				//then quickly find another avaliable spot for the customer
				$price = $spot['price'];

				if($spot = reassignSpot($dbconnect,$garage['garage_id'],$user['beginTime'],$user['endTime'],$price)){
					
					
				}
				else if($spot = reassignSpot($dbconnect,$garage['garage_id'],$user['beginTime'],$user['endTime'],($price-0.5))){
						
					
				}
				else if($spot = reassignSpot($dbconnect,$garage['garage_id'],$user['beginTime'],$user['endTime'],($price+0.5))){
						
					
				}
				else{
					echo"<h2>Sorry,No avaliable spots could be assigned now!<h2>";
					exit;			
				}
				//If seccussfully find a new spot, update database
				mysqli_query($dbconnect,"UPDATE parkingusers SET origin=".$user['spot_id'].", spot_id=".$spot['spot_id']." WHERE user_id = ".$_SESSION['user_id']);
				//mysqli_query($dbconnect,"UPDATE ");
				echo"<h2>Thanks for your report, your new spot number is ".$spot['spotNum']."<br/><a href='/garage/navigation/navigation.php'>Click to get new navigation</a></h2>"	;
				
			}
			else{
				echo"<h2>Sorry, our system does not found any record about reported vehicle</h2>";			
			}
				
				
		}
			
		else{
			echo"<h2>Sorry, our system detects that your reserved spot is not occupied</h2>";
			exit;
				
		}
		
		
	}
	else{
		//header("location:/garage/customer/index.php");
		
	}
	
	
	
	
	
	?>
    </div> <!-- /container -->

	
 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="//assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/garage/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!--<script src="//assets/js/ie10-viewport-bug-workaround.js"></script>-->
  </body>

</html>
