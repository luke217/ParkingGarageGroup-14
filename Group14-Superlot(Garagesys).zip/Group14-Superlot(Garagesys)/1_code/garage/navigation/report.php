<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Superlot</title>

    <!-- Bootstrap -->
    <link href="/garage/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

 <body>
 <?php
  session_start();
  include('../../garage/connect/dbconnect.php');
  if(!isset($_SESSION['role'])){
	  header('Location:/garage/index.php');
  }
//  	  include('../../garage/customer/navbar.php');
  ?>
	  <?php
	  include('../customer/navbar.php');
	  ?>
	<div name='login' class="jumbotron">
		 <div class="container">

      <!-- Main component for a primary marketing message or call to action -->

	<div  class="jumbotron">
	  <Table>
		<tr>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
		<a href="navigation.php"><img src="Return.gif" width="120" height="60" alt="button" /></a>
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		</tr>
	  </Table>
	  <Table>
		<tr>
		<td>
			</br>
			
			<h3>Report Overstay Car's Plate Number: <form id='reassign'action='/garage/navigation/reassign.php' method='post'><input name='plateNum' maxlength='7' style='text-transform:uppercase' placeholder="6or7 digits uppercase letter" title="6 or 7-digit plate number with uppercase letter"></form>
			</h3>
			</br>
		</td> 
		</tr>
	  </Table>
	  <Table>
		<tr>
		<td>
			<button type="button"style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button"  onclick = "(function(){document.getElementById('reassign').submit()}).call(this)" style="border: 0; padding: 0; margin:0;background: transparent">
		<img src="Report.gif" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		</tr>
	  </Table>
	  
	  
      </div>
    </div> <!-- /container -->

	<!--
    <div class="container">
     Example row of columns
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      

      <footer>
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->

 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="//assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/garage/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!--<script src="//assets/js/ie10-viewport-bug-workaround.js"></script>-->
  </body>
</html>
