
<?php
	include 'BuildAbstractedGraphfromParkinglot.php';
	///echo spot #
	$queryNum="SELECT spotNum FROM spots
	WHERE 
	spot_id=".$dest['spotid'];
	$responseNum=@mysqli_query($dbconnect, $queryNum);
	if($responseNum)
	{
		$spotNum= mysqli_fetch_assoc($responseNum)['spotNum'];
	}
	
	$queryOri="SELECT origin FROM parkingusers
	WHERE 
	spot_id=".$dest['spotid'];
	$responseOri=@mysqli_query($dbconnect, $queryOri);
	if($responseOri)
	{
		$origin= mysqli_fetch_assoc($responseOri)['origin'];
	}
	/*print_r($dest);
	echo $dest['spotid'];
	echo 'The line between point 0 and point 1 has weight: '.$weight01.'</br>';
	echo 'The line between point 0 and point 3 has weight: '.$weight03.'</br>';
	echo 'The line between point 1 and point 2 has weight: '.$weight12.'</br>';
	echo 'The line between point 1 and point 4 has weight: '.$weight14.'</br>';
	echo 'The line between point 2 and point 5 has weight: '.$weight25.'</br>';
	echo 'The line between point 3 and point 4 has weight: '.$weight34.'</br>';
	echo 'The line between point 3 and point 6 has weight: '.$weight36.'</br>';
	echo 'The line between point 4 and point 5 has weight: '.$weight45.'</br>';
	echo 'The line between point 4 and point 7 has weight: '.$weight47.'</br>';
	echo 'The line between point 5 and point 8 has weight: '.$weight58.'</br>';
	echo 'The line between point 6 and point 7 has weight: '.$weight67.'</br>';
	echo 'The line between point 6 and point 9 has weight: '.$weight69.'</br>';
	echo 'The line between point 7 and point 8 has weight: '.$weight78.'</br>';
	echo 'The line between point 7 and point 10 has weight: '.$weight710.'</br>';
	echo 'The line between point 8 and point 11 has weight: '.$weight811.'</br>';
	echo 'The line between point 9 and point 10 has weight: '.$weight910.'</br>';
	echo 'The line between point 10 and point 11 has weight: '.$weight1011.'</br>';*/

	//multidimentional array to store matrix
	$matrix= array(		//        0,         1,         2,         3,         4,         5,		 	6,		 	7,		 	8,		 	9,		 	10,	   		11,     
					array(       -1, $weight01,        -1, $weight03,        -1,        -1,		   -1,		   -1,		   -1,         -1,		    -1, 	   -1), 
					array($weight01,        -1, $weight12,        -1, $weight14,        -1,		   -1,		   -1,		   -1,         -1,		    -1, 	   -1),
					array(       -1, $weight12,        -1,		  -1,        -1, $weight25,		   -1,		   -1,		   -1,		   -1,          -1,	   	   -1), 
					array($weight03,        -1,  	   -1,        -1, $weight34,        -1, $weight36,		   -1,		   -1,         -1,		    -1, 	   -1),
					array(       -1, $weight14,        -1, $weight34,        -1, $weight45, 	   -1,	$weight47,		   -1,         -1,		    -1, 	   -1),
					array( 		 -1,        -1, $weight25,        -1, $weight45,        -1,		   -1,		   -1,	$weight58,         -1,		    -1, 	   -1),
					array(       -1, 		-1,        -1, $weight36,        -1,        -1,		   -1,	$weight67,		   -1,  $weight69,		    -1, 	   -1), 
					array(		 -1,        -1, 	   -1,        -1, $weight47,        -1,	$weight67,		   -1,	$weight78,         -1,	$weight710, 	   -1),
					array(       -1, 		-1,        -1,		  -1,        -1, $weight58,		   -1,  $weight78,		   -1,		   -1,          -1,$weight811), 
					array(		 -1,        -1,  	   -1,        -1, 		 -1,        -1, $weight69,		   -1,		   -1,         -1,	$weight910, 	   -1),
					array(       -1, 		-1,        -1, 		  -1,        -1, 		-1, 	   -1, $weight710,		   -1, $weight910,			-1,$weight1011),
					array( 		 -1,        -1, 	   -1,        -1, 		 -1,        -1,		   -1,		   -1, $weight811,         -1, $weight1011, 	   -1),
				) ;
	$distance=array();//store the first row of the matrix, &updating according to the new nodes visit

	$visited=array();
	$preD=array();//get the actual for pop

	$min=0;
	$nextNode = 0;
	for ($i = 0; $i <12; $i++)
	{
		$visited[$i] = 0;//initialization
		$preD[$i] = 0;
		for ($j = 0; $j < 12; $j++)
		{
			
			if ($matrix[$i][$j]==-1)
			$matrix[$i][$j] = 999;
		}
	}

	/* echo 'The matrix of this graph is as below(the weight 999 represent there is no connection in between two points):'.'</br>';
	for($row=0; $row<12;$row++)///print out matrix
	{
		for($col=0;$col<12; $col++)
		{
			echo $matrix[$row][$col].',';
		}
		echo '</br>';
	}*/
	

	////$root= 3;//////////////////////////////////////////"Choose the origin "
	if($origin%6==1||$origin%6==2)
	{
		if($origin<=24)
		{
			$root=0;
		}
		else if($origin<=72&&$origin>24)
		{
			$root=3;
		}
		else if($origin<=120&&$origin>72)
		{
			$root=6;
		}
		else if($origin<=144&&$origin>120)
		{
			$root=9;
		}
	}
	if($origin%6==3||$origin%6==4)
	{
		if($origin<=24)
		{
			$root=1;
		}
		else if($origin<=72&&$origin>24)
		{
			$root=4;
		}
		else if($origin<=120&&$origin>72)
		{
			$root=7;
		}
		else if($origin<=144&&$origin>120)
		{
			$root=10;
		}
	}
	if($origin%6==5||$origin%6==0)
	{
		if($origin==0)
		{
			$root=0;
		}
		else if($origin<=24)
		{
			$root=2;
		}
		else if($origin<=72&&$origin>24)
		{
			$root=5;
		}
		else if($origin<=120&&$origin>72)
		{
			$root=8;
		}
		else if($origin<=144&&$origin>120)
		{
			$root=11;
		}
	}

	if ($root != 0)
	{
		for ($i = 0; $i < 12; $i++)
		{	$temp= $matrix[$i][$root]; 
			$matrix[$i][$root]	= $matrix[$i][0];
			$matrix[$i][0]=$temp;
			}
		for ($i = 0; $i < 12; $i++)
		{   $temp= $matrix[$root][$i];
			$matrix[$root][$i]= $matrix[0][$i];
			$matrix[0][$i]=$temp;
			}
	}

	for ($i = 0; $i < 12; $i++)
	{$distance[$i] = $matrix[0][$i];}
	$distance[0] = 0;//initialize the first element
	$visited[0] = 1;


	
	
	//start the shortest path algorithm
	for ($x = 0; $x < 12; $x++)
	{
		$min = 999;
		for ($j = 0; $j < 12; $j++) //pick the shortest path when choose the nextnode
		{
			if ($min > $distance[$j] && $visited[$j] != 1)
			{
				$min = $distance[$j];
				$nextNode = $j;//pick the nextnode
			}
		}
		
		$visited[$nextNode] = 1;
		//actual start the algorithm

		for ($i = 0; $i < 12; $i++)
			if ($visited[$i] != 1)
			{
				if ($min + $matrix[$nextNode][$i] < $distance[$i])
				{
					$distance[$i] = $min + $matrix[$nextNode][$i];
					$preD[$i] = $nextNode;
				}
			}
	}
	
	$stack=array();
	//////$dest['spotid']=65;////////////////destination point
	if($dest['spotid']%6==1||$dest['spotid']%6==2)
	{
		if($dest['spotid']<=24)
		{
			$destpoint=0;
		}
		else if($dest['spotid']<=72&&$dest['spotid']>24)
		{
			$destpoint=3;
		}
		else if($dest['spotid']<=120&&$dest['spotid']>72)
		{
			$destpoint=6;
		}
		else if($dest['spotid']<=144&&$dest['spotid']>120)
		{
			$destpoint=9;
		}
	}
	if($dest['spotid']%6==3||$dest['spotid']%6==4)
	{
		if($dest['spotid']<=24)
		{
			$destpoint=1;
		}
		else if($dest['spotid']<=72&&$dest['spotid']>24)
		{
			$destpoint=4;
		}
		else if($dest['spotid']<=120&&$dest['spotid']>72)
		{
			$destpoint=7;
		}
		else if($dest['spotid']<=144&&$dest['spotid']>120)
		{
			$destpoint=10;
		}
	}
	if($dest['spotid']%6==5||$dest['spotid']%6==0)
	{
		if($dest['spotid']<=24)
		{
			$destpoint=2;
		}
		else if($dest['spotid']<=72&&$dest['spotid']>24)
		{
			$destpoint=5;
		}
		else if($dest['spotid']<=120&&$dest['spotid']>72)
		{
			$destpoint=8;
		}
		else if($dest['spotid']<=144&&$dest['spotid']>120)
		{
			$destpoint=11;
		}
	}
	
	$j = $destpoint;
		if ($root != 0)
		{	/*print_r($preD);
			echo'</br>';*/
			foreach($preD AS &$predelement)
			{
				if($predelement==0)
				{
					$predelement=$root;
				}
				else if($predelement==$root)
				{
					$predelement=0;
				}
			}
			/*print_r($preD);
			echo'</br>';*/
			$temp1=$preD['0'];
			//echo $temp1.'</br>';
			$preD['0']=$preD[$root];
			$preD[$root]=$temp1;
			/*print_r($preD);
			echo'</br>';*/
		}

			
			do{
				$j = $preD[$j];
				array_push($stack,$j);
			} while ($j != $root);
			$array1=array();
			$array2=array();
			foreach($stack AS $a)
			{
				array_push($array1, array_pop($stack));
			}
			array_push($array1, $destpoint);
			$pjl=count($array1);                           //////$pjl is the number of the joints of  the path from origin to destination
			for($it=0;$it<$pjl;$it++)
			{
				if($it==0)
				{
					continue;
				}
				array_push($array2,$array1[$it]);
			}
			array_push($array2, '-1');
			/*print_r($array1);
			print_r($array2);
			echo '</br>';*/

			/*echo 'The distance is ' . $distance[$i];// output the distance for each path
			echo '</br>';*/
		
	
	


?>
