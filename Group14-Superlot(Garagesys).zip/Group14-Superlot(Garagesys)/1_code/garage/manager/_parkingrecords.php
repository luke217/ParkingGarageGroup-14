<?php



	$records = mysqli_query($dbconnect,"SELECT * FROM parkingrecords ORDER BY endTime DESC");
	if($record  = mysqli_fetch_assoc($records)){
		echo"<table class='table table-striped table-hover'>";
		echo"<tr><td><h4>Plate Num</h4><td><h4>User ID</h4></td><td><h4>Garage ID</h4></td><td><h4>Assigned Spot ID</h4></td><td><h4>Entering Time</h4></td><td><h4>Exit Time</h4></td><td><h4>Charge</h4></td></tr>";		
		
		echo"<tr><td>".$record['plateNum']."</td><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$record['user_id']."'>".$record['user_id']."</a></td><td>".$record['garage_id']."</td><td>".$record['spot_id']."</td><td>".$record['beginTime']."</td><td>".$record['endTime']."</td>
		<td></tr>";			
			
			
		
		while($record  = mysqli_fetch_assoc($records)){
			echo"<tr><td>".$record['plateNum']."</td><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$record['user_id']."'>".$record['user_id']."</a></td><td>".$record['garage_id']."</td><td>".$record['spot_id']."</td><td>".$record['beginTime']."</td><td>".$record['endTime']."</td>
			<td>$".$record['billing']."</td></tr>";
		}
	}
	
	else{
		echo"<h2>No parking records found</h2>";
		
		
	}

	
	
	 
?>