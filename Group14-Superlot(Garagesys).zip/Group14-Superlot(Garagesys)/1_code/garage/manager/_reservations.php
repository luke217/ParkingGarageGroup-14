<?php

	echo"<table class='table table-striped table-hover'>";
	echo"<tr><td><h4>User ID</h4><td><h4>Garage ID</h4></td><td><h4>Spot ID</h4></td><td><h4>Conf Number</h4></td><td><h4>Begin Time</h4></td><td><h4>EndTime</h4></td><td><h4>Validity</h4></td><td></td></tr>";	

	$reserves = mysqli_query($dbconnect,"SELECT * FROM reservations WHERE valid = 1 ORDER BY beginTime");
	while($reserve  = mysqli_fetch_assoc($reserves)){
		echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$reserve['user_id']."'>".$reserve['user_id']."</a></td><td>".$reserve['garage_id']."</td><td>".$reserve['spot_id']."</td><td>".$reserve['confirmNum']."</td><td>".$reserve['beginTime']."</td><td>".$reserve['endTime']."</td>
		<td>";
		if($reserve['valid']){
			echo "Valid";
			
		}
		else{
			echo "Invalid";
			
		}
		echo"</td><td> <a href='/garage/manager/index.php?action=deletereserve&reserve_id=".$reserve['reserve_id']."'>delete</a></td></tr>";
	}
		$reserves = mysqli_query($dbconnect,"SELECT * FROM reservations WHERE valid = 0 ORDER BY beginTime");
	while($reserve  = mysqli_fetch_assoc($reserves)){
		echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$reserve['user_id']."'>".$reserve['user_id']."</a></td><td>".$reserve['garage_id']."</td><td>".$reserve['spot_id']."</td><td>".$reserve['confirmNum']."</td><td>".$reserve['beginTime']."</td><td>".$reserve['endTime']."</td>
		<td>";
		if($reserve['valid']){
			echo "Valid";
			
		}
		else{
			echo "Invalid";
			
		}
		echo"</td><td> <a href='/garage/manager/index.php?action=deletereserve&reserve_id=".$reserve['reserve_id']."'>delete</a></td></tr>";
	}
	echo"</table>";

	
	
	 
?>