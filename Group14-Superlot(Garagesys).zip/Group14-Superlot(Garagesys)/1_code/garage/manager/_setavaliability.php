<?php
if(isset($_POST['action'])&&$_POST['action']=='setavaliability'){
	if($_POST['avaliability']=='Unavaliable'){
		if(mysqli_query($dbconnect,"UPDATE ".$_POST['garageName']." SET disable=0 WHERE spot_id=".$_POST['spot_id'])){
			echo"<h2>successfully enabled spot</h2>";
			
		}
		else{
			
			echo"<h2>failed to enable spot</h2>";
		}
		
	}
	else if($_POST['avaliability']=='Avaliable'){
		if(mysqli_query($dbconnect,"UPDATE ".$_POST['garageName']." SET disable=1 WHERE spot_id=".$_POST['spot_id'])){
			echo"<h2>successfully disabled spot</h2>";
			
		}
		else{
			echo"<h2>failed to disabled spot</h2>";
			
		}		
	}
		

}


?>