<?php

	echo"<table class='table table-striped table-hover'>";
	echo"<tr><td><h4>User ID</h4><td><h4>First Name</h4></td><td><h4>Last Name</h4></td><td><h4>Username</h4></td><td><h4>License Plate</h4></td><td><h4>Phone</h4></td><td><h4>Billing</h4></td><td></td></tr>";	

	$users = mysqli_query($dbconnect,"SELECT * FROM users");
	while($user  = mysqli_fetch_assoc($users)){
		echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$user['user_id']."'>".$user['user_id']."</a></td><td>".$user['firstName']."</td><td>".$user['lastName']."</td><td>".$user['username']."</td><td>".$user['plateNum']."</td><td>".$user['phoneNum']."</td><td>".$user['billing']."</td>
		<td> <a href='/garage/manager/index.php?action=deleteuser&user_id=".$user['user_id']."'>delete</a></td></tr>";
	}
	echo"</table>";
 	echo "<a href='/garage/manager/index.php?action=adduser'>Add New Account</a>";
	
	
	 
?>