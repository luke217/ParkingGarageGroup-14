 <?php
 
 function SpotsAvaliability($dbconnect,$garage_id,$beginTime,$endTime){
	 return mysqli_query($dbconnect,"SELECT DISTINCT spot_id FROM reservations 
	 WHERE garage_id=".$garage_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' )) 
	 ORDER BY spot_id");
 }
 
 
 function reassignSpot($dbconnect,$user_id,$plateNum){
	 $record = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE user_id=".$user_id));
	 if(mysqli_query($dbconnect,"INSERT INTO reports (user_id, plateNum,spot_id,time) 
		 VALUES (".$user_id.",'".$plateNum."',".$record['spot_id'].",'".date("Y-m-d H:i:s")."')".$user_id)){
			 
			 echo "successfully saved report to database";
		 }
		else{
			 
			echo "Failed to saved report to database"; 
		 }
	 $spots = 	 SpotsAvaliability($dbconnect,$garage_id,$beginTime,$endTime);
	 
	 $garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id=".$record['garage_id']));
	 
	 while($spot = mysqli_fetch_assoc($spots)){
		 $s = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id=".$spot['spot_id']));
		 if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE garage_id = ".$garage_id." AND spot_id=".$spot['spot_id']))){
			continue;			 
		 }
		 if($s['state']==0&&$s['disable']==0){
			 if(mysqli_query($dbconnect,"UPDATE parkingusers SET spot_id = ".$s['spot_id']." WHERE user_id = ".$user_id) {
				 
			 echo "successfully updated parkinguser database";				 
				 
				 
				 
			 }
			 if(mysqli_query($dbconnect,"UPDATE reservations SET spot_id = ".$s['spot_id']." WHERE beginTime = '".$record['beginTime']."'") {
				 
			 echo "successfully updated reservation database";			 
			 
			 
			 
			 }
			 return $s;
		 }
		 
	 }
	 return null;
	 
	 
	 
 }
 ?>