
         <style type="text/css">
          #map{ width:300px; height: 300px; }
        </style>
		 <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-ZTYC3nb4nJxMsXuFvCjwcx97xsnX6_o&callback=initMap"></script>
        <script type="text/javascript" src="/garage/js/map.js"></script>        
        <!--map div-->
        <div id="map"></div>       
        <!--our form-->


