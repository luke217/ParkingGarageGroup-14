<?php



	$reports = mysqli_query($dbconnect,"SELECT * FROM reports WHERE valid = 0 ORDER BY Time");
	if(mysqli_fetch_assoc($reports)){
		echo"<table class='table table-striped table-hover'>";
		echo"<tr><td><h4>Reporter User ID</h4><td><h4>Reported Plate Number</h4></td><td><h4>Garage ID</h4></td><td><h4>Spot ID</h4></td><td><h4>Time</h4></td><td><h4>Validity</h4></td><td></td></tr>";		
		
		
		
		echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$report['user_id']."'>".$report['user_id']."</a></td><td>".$report['plateNum']."</td><td>".$report['garage_id']."</td><td>".$reserve['spot_id']."</td><td>".$reserve['Time']."</td><td>".$reserve['endTime']."</td>
		<td>";
		if($reserve['valid']){
			echo "Valid";
			
		}
		else{
			echo "Invalid";
			
		}
		echo"</td><td> <a href='/garage/manager/index.php?action=handlereport&report_id=".$report['report_id']."'>Handle</a></td></tr>";
		
		
	
		while($report  = mysqli_fetch_assoc($reports)){
			echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$report['user_id']."'>".$report['user_id']."</a></td><td>".$report['plateNum']."</td><td>".$report['garage_id']."</td><td>".$reserve['spot_id']."</td><td>".$reserve['Time']."</td><td>".$reserve['endTime']."</td>
			<td>";
			if($reserve['valid']){
				echo "Valid";
				
			}
			else{
				echo "Invalid";
				
			}
			echo"</td><td> <a href='/garage/manager/index.php?action=handlereport&report_id=".$report['report_id']."'>Handle</a></td></tr>";
		}
	}
	else {
		echo"<h3>No Report Record Found</h3>";
		
		
	}
	
	
	 
?>