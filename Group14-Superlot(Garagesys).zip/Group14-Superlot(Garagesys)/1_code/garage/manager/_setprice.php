<?php
if(isset($_POST['action'])&&$_POST['action']=='setprice'){

		if(mysqli_query($dbconnect,"UPDATE ".$_POST['garageName']." SET price=".$_POST['newprice']." WHERE spot_id=".$_POST['spot_id'])){
			echo"<h2>successfully changed price</h2>";
			
		}
		else{
			echo"<h2>failed to change price</h2>";
			
		}		
	
		


}
?>