<?php
include("manager_lib.php");
if(!isset($_POST['garageName'])){
	$result=mysqli_query($dbconnect,'SELECT garageName FROM garages');

	echo"<form action='/garage/manager/index.php' method='post'>
		<input hidden value = 'checkGarage' name='action'>";
	echo"Select the garage you want to check:<select name='garageName' onchange ='selectGarage()'>";
	while($garagName = mysqli_fetch_assoc($result)['garageName'])
	{
		echo"<option>".$garagName."</option>";
	}
	echo"</select> </br> <input type='submit' value = 'Check State' class='btn btn-primary' ></form>";
	
	
	echo"<form action='/garage/manager/index.php' method='post'>
	<input  hidden name='garageName' id ='garageName'>
	<input hidden value = 'checkParkingUsers' name='action'>
	<input type='submit' value = 'Check Parking Users' class='btn btn-primary' >
	</form>";
	echo"<br/><a href='/garage/manager/index.php?action=newGarage' class='btn btn-default' >Create New Garage</a>
	<script>
	(function(){
		document.getElementById('garageName').value = document.getElementsByTagName('select')[0].value;
				
	})();
	function selectGarage(){
		document.getElementById('garageName').value= document.getElementsByTagName('select')[0].value;		
		
	}
	</script>
	";
}

else{
	

?>


<?php
managerGarageState($dbconnect,$_POST['garageName']);
}
?>