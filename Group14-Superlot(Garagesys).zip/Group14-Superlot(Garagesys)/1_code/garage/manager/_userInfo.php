<?php

$user_id = $_GET['user_id'];

$user = mysqli_fetch_assoc(mysqli_query($dbconnect,'SELECT * FROM users WHERE user_id='.$user_id));
echo"<h3>".$user['firstName']." ".$user['lastName']."</h3>";
echo"</br>Email/Username: ".$user['username'];
echo"</br>License Plate: ".$user['plateNum'];
echo"</br>Phone:".$user['phoneNum'];
echo"</br>Billing:".$user['billing'];

?>
