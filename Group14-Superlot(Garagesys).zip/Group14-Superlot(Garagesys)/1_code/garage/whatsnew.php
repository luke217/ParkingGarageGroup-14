	  <div id='whatsnew'style="position:fixed;top:200px;right:15px;">

	  <br/>
	  <a  onclick='commercial()' style='height:50px; width:50px;'>
			  <img src="/garage/commercial/monkey.jpg">
	  </a>
	  <?php
	  $commercials = mysqli_query($dbconnect,'SELECT * FROM commercial');
	  while($commercial = mysqli_fetch_assoc($commercials)){
		  echo "<br/><a style= 'visibility:hidden; height:50px; width:50px' href='/garage/commercial/index.php?action=".$commercial['type']."' name= 'commercial'><img style='height: 75px; width:75px' title= '".$commercial['type']."' src = '/garage/commercial/".$commercial['type']."_icon.jpg'></a>";
	  }
	  ?>
	  <br/><br/><a style= 'visibility:hidden; height:50px; width:50px' name= 'commercial' onclick= 'hideads()'>
		<img style="height: 75px; width:75px" title= 'close ads' src = '/garage/commercial/cross.png'>
	  </a>
	  </div>
	  <script>

		function commercial(){		
			var ads = document.getElementsByName('commercial');
			var vis;
			if(ads[0].style.visibility=='hidden') {
				vis = 'visible';
			}	
			else{
				vis= 'hidden';			
			}
			for(var i=0;i<ads.length;i++){
				ads[i].style.visibility=vis;			
			}
	  }
	  function hideads(){
		  document.getElementById('whatsnew').hidden='hidden';
		  
	  }

		
		
		
		
		
	  </script>