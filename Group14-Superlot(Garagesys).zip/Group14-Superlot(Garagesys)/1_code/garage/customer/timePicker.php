<form action = "/garage/customer/index.php" method = "post">
	<?php
$currentDate = date("y-m-d H:i:s");
//$currentDate = roundToNearestHalfHour(date("y-m-d H:i:s"));
$maxDate = date("y-m-d H:i:s",strtotime($currentDate."+7 day"));

$result=mysqli_query($dbconnect,'SELECT garageName FROM garages');

	echo"<input hidden value = 'checkReserveGarage' name='action'>";
	echo"Select the garage you want to park in:<select name='garageName'>";
	while($garagName = mysqli_fetch_assoc($result)['garageName'])
	{
		echo"<option>".$garagName."</option>";
	}
	echo"</select>";


?>




<div>
<h4>BeginTime</h4>
Year:
<select name='select' id = 'y1'>
<?php
$y1 = date("Y",strtotime($currentDate)); 
$y2 = date("Y",strtotime($maxDate));

echo "<option selected>".$y1."</option>";
if($y1 != $y2){	
	echo "<option>".$y2."</option>";
} 
?>
</select>
Month:
<select name='select' id = 'm1' >
<?php
$m1 = date("m",strtotime($currentDate)); 
$m2 = date("m",strtotime($maxDate));

echo "<option selected>".$m1."</option>";
if($m1 != $m2){	
	echo "<option>".$m2."</option>";
} 
?>
</select>
Day:
<select name='select' id = 'd1'>
<?php
for($i = 1;$i<=31; $i++){
	echo "<option ";
	if($i==date('d'))
		echo"selected";
	echo ">".$i."</option>";
	}
?>
</select>
Time:
<select name='select' id = 'h1'>
<?php
for($i = 0;$i<=23; $i++){
	echo "<option ";
	if($i==date('H'))
		echo"selected";
	echo ">".$i."</option>";
	}
?>

</select>
:
<select name='select' id = 'i1'>
<option>00</option>
<option>30</option>
</select>
<input name = "beginTime"  id = "t1"  >
</div>
<br/>
<div>
<h4>EndTime</h4>
Year:
<select name='select' id = 'y2'>
<?php
$y1 = date("Y",strtotime($currentDate)); 
$y2 = date("Y",strtotime($maxDate));

echo "<option selected>".$y1."</option>";
if($y1 != $y2){	
	echo "<option>".$y2."</option>";
} 
?>
</select>
Month:
<select name='select' id = 'm2' >
<?php
$m1 = date("m",strtotime($currentDate)); 
$m2 = date("m",strtotime($maxDate));

echo "<option selected>".$m1."</option>";
if($m1 != $m2){	
	echo "<option>".$m2."</option>";
} 
?>
</select>
Day:
<select name='select' id = 'd2'>
<?php
for($i = 1;$i<=31; $i++){
	echo "<option ";
	if($i==date('d'))
		echo"selected='selected'";
	echo ">".$i."</option>";
	}
?>
</select>
Time:
<select name='select' id = 'h2'>
<?php
for($i = 0;$i<=23; $i++){
	echo "<option ";
	if($i==date('H'))
		echo"selected";
	echo ">".$i."</option>";
	}
?>
</select>
:
<select name='select' id = 'i2'>
<option>00</option>
<option>30</option>
</select>
<input name = "endTime"  id = "t2"  >
</div>


	<button type="submit" name='checkTime' class='btn btn-lg btn-primary'>Check Time</button>
	</form>
	<script >

(function(){

	var elements = document.getElementsByName("select");
	for(var i=0;i<elements.length;i++){
				elements[i].addEventListener("change",function(){
			var s1=document.getElementById('y1').value+"-"
					+document.getElementById('m1').value+"-"
					+document.getElementById('d1').value+" "
					+document.getElementById('h1').value+":"
					+document.getElementById('i1').value+":"+"00";
			var s2 =document.getElementById('y2').value+"-"
					+document.getElementById('m2').value+"-"
					+document.getElementById('d2').value+" "
					+document.getElementById('h2').value+":"
					+document.getElementById('i2').value+":"+"00";
					
			document.getElementById('t1').value	= s1;	
			document.getElementById('t2').value	= s2;	
			
		/*												
			var d1 = new Date(s1);
			var d2 = new Date(s2);			
			document.getElementById('t1').value =s1;
			{
			var day = document.getElementById('d2').value;
			var hour = document.getElementById('h2').value;			
			if(!d2||((d2-d1)<7200000)){
				if(d1.getHours()>=22){
					d2.setDate(d1.getDay()+1);

				}
				d2.setHours(d1.getHours()+2);
						document.getElementById('t2').value =d2.getDate()+" "
												+d2.getHours()+":"
												+document.getElementById('i2').value+":"+"00";	
			}
			else{
				
				document.getElementById('t2').value=s2.toString();
			}


			}
			*/
		});

		
	}
	
	
})();
		
</script>