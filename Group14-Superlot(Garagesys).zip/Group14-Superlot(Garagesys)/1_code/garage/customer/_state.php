<?php
include("customer_lib.php");
if(!isset($_POST['garageName'])){
	$result=mysqli_query($dbconnect,'SELECT garageName FROM garages');

	echo"<form action='/garage/customer/index.php' method='post'>
		<input hidden value = 'checkGarage' name='action'>";
	echo"Select the garage you want to check:<select name='garageName' class='selectpicker'>";
	while($garagName = mysqli_fetch_assoc($result)['garageName'])
	{
		echo"<option>".$garagName."</option>";
	}
	echo"</select><br/><input type='submit' value = 'Check State' class='btn btn-primary '></form>";
}

else{
	customerGarageState($dbconnect,$_POST['garageName']);
}
?>
