
<h2 style="font-family:Raleway,sans-serif; color:black;text-align: center;font-weight: 900;">Welcome to Superlot !</h2>

<style>
    
    #container{
        width:950px;
        height:auto;
        margin-left: auto;
        margin-right: auto;
        
    }
    #mainbody{
        width:650px;
        height:360px;
        
    }
    
    #sidebar{
        width: 250;
        height:450;
       
        float:right;
        
    }


</style>

<body>
    <div id="container"><p style="float:right"><?php
	
	$sqlresult = mysqli_query($dbconnect,'SELECT * FROM reservations WHERE valid=0 AND user_id='.$_SESSION['user_id'].' ORDER BY beginTime');

	if($reserve =mysqli_fetch_assoc($sqlresult)){
            echo"<h3>Reserve History:</h3>";
			echo"<table class='table table-striped table-hover'>";
			echo"<tr><td><h4>Begin Time</h4><td><h4>End Time</h4></td><td><h4>Comfirmation Number</h4></td><td><h4>Garage Name</h4></td><td></td></tr>";	
			echo"<tr><td>".$reserve['beginTime']."</td><td>".$reserve['endTime']."</td><td>".$reserve['confirmNum']."</td>
				<td>".mysqli_fetch_assoc(mysqli_query($dbconnect,'SELECT * FROM garages WHERE garage_id='.$reserve["garage_id"]))['garageName']."</td>
				<td> <a href='/garage/customer/index.php?action=deletereserve&reserve_id=".$reserve['reserve_id']."'>delete</a></td></tr>";
				
				
			while($reserve  = mysqli_fetch_assoc($sqlresult)){
				echo"<tr><td>".$reserve['beginTime']."</td><td>".$reserve['endTime']."</td><td>".$reserve['confirmNum']."</td>
				<td>".mysqli_fetch_assoc(mysqli_query($dbconnect,'SELECT * FROM garages WHERE garage_id='.$reserve["garage_id"]))['garageName']."</td>
				<td> <a href='/garage/customer/index.php?action=deletereserve&reserve_id=".$reserve['reserve_id']."'>delete</a></td></tr>";
			}
			echo"</table>";
            
    }
    else{
        echo"<h3>Not Reservation Record Found</h3>";   
    }
        ?>
</p>
<div id="mainbody">
    <img src="/garage/img/homepage background.jpg" style="width:50%;height:70%;float:left;margin-right:10px;margin-bottom:5px;s"/>
    <p><i>Welcome to the New Jersey's best parking garage with most advanced technology! Looking to make a reservation? No problem! Login in on the right hand side of the page to access your account.If you don't need a reservation and are just stopping by, feel free to navigate our website to learn more about what we do and how we can help you.</i></p>
        </div>

<div id="sidebar">
        
</div>
</div>

</body>