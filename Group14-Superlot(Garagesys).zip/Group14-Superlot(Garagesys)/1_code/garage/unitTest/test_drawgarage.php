<?php
function drawSquare($size,$singleSide=0,$left=1){
	echo"<table>";
	if( $singleSide ||($size%2) ){//if odd size draw only singleside
		if($left){
			$src = 'empty_L.jpg';			
		}
		else{
			$src = 'empty_R.jpg';						
		}
		for($i=0;$i<$size;$i++){
			echo"<tr>
			<td>
			<a name = 'spot' style = 'margin:0;border:0;padding:0'>
			<img src='".$src."' title= 'price'>
			</a>
			</td>
			</tr>";
		}
		
	}
	else{
		for($i=0;$i<$size/2;$i++){
			echo"<tr>
			<td>
			<a name = 'spot' style = 'margin:0;border:0;padding:0'>
			<img src='empty_L.jpg' title= 'price'>
			</a>
			</td>
			
			<td>
			<a name = 'spot' style = 'margin:0;border:0;padding:0'>
			<img src='empty_R.jpg' title= 'price'>
			</a>
			</td>
			</tr>";
		}
		
		
	}
	echo "</table>";
}
function drawGarag($columnSize,$rowSize,$squareSize){
	
	
	$edgeSize = $squareSize%2 ? $squareSize : $squareSize/2;	
	echo"<table style= 'background-color:gray'>";
	echo"<tr style= 'height:80px'></tr>	";
	for($i=0;$i<$columnSize;$i++){
		
		echo"<tr>";
		echo"<td>";
		drawSquare($edgeSize,1,0);
		echo"</td>";
		echo"<td style= 'width:130px'></td>";	
		for($j=0;$j<$rowSize;$j++){
			echo"<td>";
			drawSquare($squareSize);
			echo"</td>";
			echo"<td style= 'width:130px'></td>";
		}
		
		echo"<td>";
		drawSquare($edgeSize,1,1);
		echo"</td>";
		echo"</tr>";
		echo"<tr style= 'height:80px'></tr>	";
		
	}

	echo"</table>";	
}

function drawSections($sectionLength,$sectionWidth,$sectionNum){
	for($i=0;$i<$sectionLength;$i++){
		echo"<tr>";
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		
		for($j=0;$j<$sectionNum;$j++){			
			echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
			if($sectionWidth==2){
				echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";				
			}
			echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		}
		
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
		echo"</tr>";
	}
	
}
function drawPassWay($width){
	echo"<tr>";
	for($i=0;$i<$width;$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";		
	}
	echo"</tr>";
}
function drawGarage($columnSize,$rowSize,$sectionSize,$singleSide=0){

	$sectionLength = $sectionSize/2;
	$sectionWidth = 2;
	if($singleSide==1 || $sectionSize%2==1) {
		$sectionLength = $sectionSize;
		$sectionWidth = 1;		
	}
	//draw entrance row
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"<td><a name = 'entrance' style = 'margin:0;border:0;padding:0'><img src='/garage/img/entrance.jpg' title= 'entrance'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
	for($i=1;$i<$columnSize;$i++){
		drawSections($sectionLength,$sectionWidth,$rowSize);
		drawPassWay($rowSize*($sectionWidth+1)+3);
	}
	drawSections($sectionLength,$sectionWidth,$rowSize);
	//draw exit row
	
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'exit' style = 'margin:0;border:0;padding:0'><img src='/garage/img/exit.jpg' title= 'exit'></a></td>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
}

?>
<html>
<body>
<?php
drawGarage(2,3,4);
?>
<script>
(function(){
	var spots = document.getElementsByName('spot');
	
	for(var i=0;i<spots.length;i++){
		spots[i].href = window.location.href.split('?')[0]+'?spotid='+i;
		
	}
	
	
})();
</script>
</body>
</html>