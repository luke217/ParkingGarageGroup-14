<?php
session_start();
$_SESSION['message']='';
  include('../connect/dbconnect.php');
if(isset($_POST['username'])){
    if($_POST['password'] != $_POST['confirmpassword']){
		$_SESSION['message']="Two password does not match!";
	}
	else{
        $userNameCheck=mysqli_query($dbconnect,"SELECT * FROM users WHERE username='".$_POST['username']."'");
		$plateNumCheck=mysqli_query($dbconnect,"SELECT * FROM users WHERE plateNum='".$_POST['plateNum']."'");
        if(mysqli_fetch_assoc($userNameCheck)){
			
			$_SESSION['message']="The email address has been used!";

			

		}
        else if(mysqli_fetch_assoc($plateNumCheck)){
            $_SESSION['message']="This Licence Plate is already registered.";
		}
        else{
            $sql="INSERT INTO users (firstName, lastName,username,password,plateNum,phoneNum )
			  VALUES('".$_POST['firstName']."','".$_POST['lastName']."','".$_POST['username']."','".$_POST['password']."','".$_POST['plateNum']."','".$_POST['phoneNum']."')";
            if(mysqli_query($dbconnect,$sql)){
                echo  "<h2>Registration successful!</h2>";
                
            }
            else{
				echo "<h2>Sorry, the registration is failed!</h2>";
			} 
        }       
	}
}
?>
<link href="//db.onlinewebfonts.com/c/a4e256ed67403c6ad5d43937ed48a77b?family=Core+Sans+N+W01+35+Light" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="/garage/css/registration.css" type="text/css">
<html>
<body style="background:url('/garage/img/registration.jpeg') #0f2439 no-repeat">
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" action="/garage/unitTest/test_registration.php" method="post" enctype="multipart/form-data" autocomplete="off">
      <div class="alert alert-error"><?php
	  if(isset($_SESSION['message'])){
		  echo $_SESSION['message'];
		  unset ($_SESSION['message']);
		  
	  }?></div>
      <input type="text" placeholder="First Name" name="firstName" required />
      <input type="text" placeholder="Last Name" name="lastName" required />
      <input type="email" placeholder="Email" name="username" required />
      <input type="password" placeholder="Password" name="password" autocomplete="new-password" required />
      <input type="password" placeholder="Confirm Password" name="confirmpassword" autocomplete="new-password" required />
      <input type="text" placeholder="Licnese" style="text-transform:uppercase" maxlength='7' name="plateNum" required />
      <input type="tel" placeholder="Phone" name="phoneNum"  />
      <input type="submit" value="Register" name="register" class="btn btn-block btn-primary" />
    </form>
  </div>
</div>
</body>
</html>