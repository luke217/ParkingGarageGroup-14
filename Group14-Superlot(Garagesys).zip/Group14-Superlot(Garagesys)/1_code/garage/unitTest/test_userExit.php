<header><h1>This is a test program that simulates User Exit in garage</h1></header>
<body>
<?php
	include('../connect/dbconnect.php');
	include("../console/console_lib.php");
	
	
	//first identify the role of incoming user
	session_start();
	$garage_id = 1;
	if(isset($_GET['garage_id'])&&($_GET['garage_id']!=NULL)){
		$_SESSION['garage_id'] = $_GET['garage_id'];
		
	}
	
	if(!isset($_SESSION['garage_id'])){
		
		$_SESSION['garage_id'] = 1;
	}
	
	if(isset($_GET['curTime'])){
		$_SESSION['curTime'] = $_GET['curTime'];
		
	}
	if(isset($_GET['action'])&&($_GET['action']=='reset')){
		if(mysqli_query($dbconnect,"UPDATE reservations SET valid = 1")){
			echo"<h2>Reset Validity of All Reservations</h2>";
			
		}
		else{
			echo"<h2>Failed To Reset Validity of All Reservations</h2>";
			
		}
		exit;
	}
	else if(isset($_GET['action'])&&($_GET['action']=='sensorOn')){
		
		$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id  =".$_SESSION['garage_id']));	
		
		if(mysqli_query($dbconnect,"UPDATE ".$garage['garageName']." SET state = 1 WHERE spot_id=".$_GET['spot_id'])){
			echo"<h2>Spot ID = ".$_GET['spot_id']." Sensor is On</h2>";
			
		}
		else{
			echo"<h2>Failed To Turn On Sensor</h2>";
			
		}
		exit;
	}
	else if(isset($_GET['action'])&&($_GET['action']=='sensorOFF')){
		$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id  =".$_SESSION['garage_id']));	
		
		if(mysqli_query($dbconnect,"UPDATE ".$garage['garageName']." SET state = 0 WHERE spot_id=".$_GET['spot_id'])){
			echo"<h2>Spot ID = ".$_GET['spot_id']." Sensor is OFF</h2>";
			
		}
		else{
			echo"<h2>Failed To Turn On Sensor</h2>";
			
		}
		exit;
	}
	
	else if(isset($_GET['action'])&&($_GET['action']=='exit')){
		if(isset($_GET['plateNum'])){
			if($record = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE plateNum  ='".$_GET['plateNum']."'"))){
				
				$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id  =".$record['garage_id']));
				$price = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id  =".$record['spot_id']))['price'];
				//justify whether this car is overstaying
				$curTime = getCurrentTime();
				if(isset($_GET['curTime'])){
					
				$curTime = $_GET['curTime'];
				}
				
				if((strtotime($curTime)-strtotime($record['beginTime']))<0){
					echo"<h1>ERROR: INVALID EXIT TIME</h1>";				
					exit;
				}
				
				$endTime = $record['endTime'];
				$diff = strtotime($curTime)-strtotime($endTime);
				if($diff>1800){//if exit time is late half hour, it is treated as overstay
					echo"<h2>Car overstayed, extra charge made</h2>";
					$duration = (strtotime($curTime)-strtotime($record['beginTime']))/3600;
					$billing = $price*$duration;
				}
				else{
					$duration = (strtotime($record['endTime'])-strtotime($record['beginTime']))/3600;
					$billing = $price*$duration;
				}
				
				//var_dump($duration);
				
				if(mysqli_query($dbconnect,"INSERT INTO parkingRecords (plateNum,user_id,garage_id,spot_id,beginTime,endTime,billing) 
					VALUES ('".$record['plateNum']."',".$record['user_id']." ,".$record['garage_id'].",".$record['spot_id']." , '".$record['beginTime']."','".$curTime."',".$billing.")")){
					echo"<br/>Successfully Update Parking Record";
					if(mysqli_query($dbconnect,"DELETE FROM parkingusers WHERE plateNum='".$_GET['plateNum']."'")){
						echo'<br/>Successfully removed from parkingusers';
						if(mysqli_query($dbconnect,"UPDATE users SET billing = billing +".$billing." WHERE user_id=".$record['user_id'])){
								echo"<br/>Successfully Update User Billing";
						}
						else{
							echo"<br/>Fail to Update User Billing";
							
						}
					}
					else{
						echo'<br/>Fail to remove from parkingusers';
						
					}
						
				}
				else{
					echo"<br/>Fail to Update Parking Record";
					
				}
				
			}
			else{
				echo '<br/><h2>parking record not found.</h2>';				
			}
		
		}
		else{
			//echo "plateNum not provided";
		}
		
	}
	else{
		if(isset($_GET['garage_id'])&&($_GET['garage_id']!=NULL))
		{
				$garage_id = $_GET['garage_id'];
		}
		if(isset($_GET['plateNum'])){
			if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE plateNum='".$_GET['plateNum']."'"))){
				echo"<h2>ERROR: A car with same Plate Number is already inside the garage!</h2>";
				exit;
				
			}
			
			//var_dump($_GET['plateNum']);
			$plateNum = $_GET['plateNum'];
			$user_sql = "SELECT user_id FROM users WHERE plateNum='".$plateNum."'";
			$user_query = mysqli_query($dbconnect,$user_sql);
			$user = mysqli_fetch_assoc($user_query);
			var_dump($user);
			if($user['user_id']){//if user is found via plateNum
				header("Location: registered.php?user_id=".$user['user_id']."&garage_id=".$garage_id);
		
			}
			else{
				
				var_dump($_SESSION);
				header("Location: walkin.php?plateNum=".$plateNum."&garage_id=".$garage_id);
			}
			//$reserve_sql = "SELECT spot_id FROM spots JOIN reservations WHERE plateNum=".$GET['plateNum'];
			//$reserve = mysqli_fetch_assoc(mysqli_query($dbconnect,$user_sql));
		}
		else{
			//echo "plateNum not provided";
		}
	}
?>

<?php
$currentDate = date("y-m-d H:i:s");
$maxDate = date("y-m-d H:i:s",strtotime($currentDate."+7 day"));
echo"<h2>Current Garage ID:".$garage_id."</h2>";
?>


<link href="/garage/css/bootstrap.min.css" rel="stylesheet">
<div name="login" class="jumbotron" >

<form action = "/garage/console/index.php" method="get">

<input name= 'plateNum' required  style="text-transform:uppercase" maxlength='6' placeholder='Plate Number'>

Year:
<select name='select' id = 'y2'>
<?php
$y1 = date("Y",strtotime($currentDate)); 
$y2 = date("Y",strtotime($maxDate));

echo "<option selected>".$y1."</option>";
if($y1 != $y2){	
	echo "<option>".$y2."</option>";
} 
?>
</select>
Month:
<select name='select' id = 'm2' >
<?php
$m1 = date("m",strtotime($currentDate)); 
$m2 = date("m",strtotime($maxDate));

echo "<option selected>".$m1."</option>";
if($m1 != $m2){	
	echo "<option>".$m2."</option>";
} 
?>
</select>
Day:
<select name='select' id = 'd2'>
<?php
for($i = 1;$i<=31; $i++){
	echo "<option ";
	if($i==date('d'))
		echo"selected='selected'";
	echo ">".$i."</option>";
	}
?>
</select>
Time:
<select name='select' id = 'h2'>
<?php
for($i = 0;$i<=23; $i++){
	echo "<option ";
	if($i==date('H'))
		echo"selected";
	echo ">".$i."</option>";
	}
?>
</select>
:
<select name='select' id = 'i2'>
<?php
for($i=0;$i<6;$i++){
	echo"<option>".$i."0</option>";	
}
 ?>
</select>

<input name = 'curTime' placeholder='Set Exit Time' id='t2'>
<input hidden name= 'action' value = 'exit'>
<input type = 'submit' class='btn btn-default' value = "Simulate Car Exiting">
</form>

<script>

(function(){

	var elements = document.getElementsByName("select");
	for(var i=0;i<elements.length;i++){
				elements[i].addEventListener("change",function(){
			var s1=document.getElementById('y1').value+"-"
					+document.getElementById('m1').value+"-"
					+document.getElementById('d1').value+" "
					+document.getElementById('h1').value+":"
					+document.getElementById('i1').value+":"+"00";
			var s2 =document.getElementById('y2').value+"-"
					+document.getElementById('m2').value+"-"
					+document.getElementById('d2').value+" "
					+document.getElementById('h2').value+":"
					+document.getElementById('i2').value+":"+"00";
			
			var s3 =document.getElementById('y3').value+"-"
					+document.getElementById('m3').value+"-"
					+document.getElementById('d3').value+" "
					+document.getElementById('h3').value+":"
					+document.getElementById('i3').value+":"+"00";
					
			document.getElementById('t1').value	= s1;	
			document.getElementById('t2').value	= s2;	
			document.getElementById('t3').value	= s3;	
		/*												
			var d1 = new Date(s1);
			var d2 = new Date(s2);			
			document.getElementById('t1').value =s1;
			{
			var day = document.getElementById('d2').value;
			var hour = document.getElementById('h2').value;			
			if(!d2||((d2-d1)<7200000)){
				if(d1.getHours()>=22){
					d2.setDate(d1.getDay()+1);

				}
				d2.setHours(d1.getHours()+2);
						document.getElementById('t2').value =d2.getDate()+" "
												+d2.getHours()+":"
												+document.getElementById('i2').value+":"+"00";	
			}
			else{
				
				document.getElementById('t2').value=s2.toString();
			}


			}
			*/
		});

		
	}
	
	
})();
		
</script>


