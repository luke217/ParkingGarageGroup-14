<?php

include('../../garage/connect/dbconnect.php');
include("console_lib.php");
echo '<div name="login" class="jumbotron">';
session_start();
if(!isset($_SESSION['erroCount'])){
		$_SESSION['erroCount']=0;
}
if(isset($_GET['plateNum'])){
	$_SESSION['plateNum']=$_GET['plateNum'];
	
}
$currentTime = date("Y-m-d H:i:s");

if(isset($_SESSION['curTime'])){
	$currentTime = $_SESSION['curTime'];

}



if(isset($_GET['entrance'])){
	echo "Entrance to the first floor has been provided<br/>";
	
	unset($_SESSION['erroCount']);
	unset($_SESSION['plateNum']);
	exit;
	
}
else if(isset($_GET['confEnter'])){
		echo"
		<h2>Please Enter the 10-digit Confirmation Number</h2>
		<form action='walkin.php' method = 'post'>
		<input type='text' name='confNum' maxlength=10>
		<input type = 'submit' class='btn btn-lg btn-primary' value = 'Enter'>
		</form>";
	}
else if(isset($_POST['confNum'])&&($_POST['confNum']!=NULL)){
	$confNum  = $_POST['confNum'];
	$reserve= mysqli_fetch_assoc(mysqli_query($dbconnect, "SELECT * FROM reservations WHERE valid=1 AND confirmNum=".$confNum));

	
	echo "Current Time:".$currentTime;
	if(isReserveAvaliable($reserve,$currentTime)){
		header("Location: registered.php?reserve_id=".$reserve['reserve_id']."&plateNum=".$_SESSION['plateNum']);	
	}
	else{
		$_SESSION['erroCount']=$_SESSION['erroCount']+1;
		if($_SESSION['erroCount']>=3){
			echo "<h2>Incorrect Confirmation Number or Reservation Not avaliable<br/>
			Too many attempts<br/>
			Entrance to the first floor has been provided<br/></h2>";
			unset($_SESSION['erroCount']);
			unset($_SESSION['plateNum']);
			if(isset($_SESSION['curTime'])){
				unset($_SESSION['curTime']);
			}
			exit;
		}
		echo "<h2>Incorrect Confirmation Number or Reservation Not avaliable</h2><br/>
		<form action='walkin.php' >
		<input type = 'submit' class='btn btn-lg btn-primary' name='entrance' value = 'I am a walk-in user'>
		</form>
		<form action='walkin.php'>
		<input type = 'submit' class='btn btn-lg btn-primary' name ='confEnter' value = 'Re-enter confirmation Number'>
		</form>";
	}
}
else{
?>
<h1>WELCOME</h1>
<form action='walkin.php' >
<input type = "submit" class='btn btn-lg btn-primary' name='entrance' value = "I am a walk-in user">
</form>
<form action='walkin.php'>
<input type = "submit" class='btn btn-lg btn-primary' name ='confEnter' value = "I have a confirmation Number">
</form>

<?php
}
?>