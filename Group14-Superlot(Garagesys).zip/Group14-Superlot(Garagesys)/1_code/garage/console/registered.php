<?php
include('../../garage/connect/dbconnect.php');
include("console_lib.php");
session_start();


echo '<div name="login" class="jumbotron">';
$currentTime = roundToNearestHalfHour(getCurrentTime());

	if(isset($_GET['curTime'])){
		$_SESSION['curTime'] = $_GET['curTime'];
		
	}

if(isset($_SESSION['curTime'])){
	$currentTime = $_SESSION['curTime'];
	unset($_SESSION['curTime']);
}

$garage_id = 1;

if(isset($_SESSION['garage_id'])&&($_SESSION['garage_id']!=NULL)){
	$garage_id = $_SESSION['garage_id'];		
}
$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id=".$garage_id ));


if(isset($_GET['user_id'])){//access by plateNum


	//first find whether there is avaliable reservation
	$user= mysqli_fetch_assoc(mysqli_query($dbconnect,
	"SELECT * FROM users WHERE user_id=".$_GET['user_id']));
	

	
	$reserve = mysqli_fetch_assoc(mysqli_query($dbconnect,
	"SELECT * FROM reservations WHERE valid=1 AND user_id=".$_GET['user_id']." AND garage_id=".$garage_id." AND endTime >'".$currentTime."' ORDER BY beginTime"));


	
	//var_dump($garage);
	if(isReserveAvaliable($reserve,$currentTime)){
		//found avaliable reservation;
		$spot = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id=".$reserve['spot_id']));
		if($spot['state']||$spot['disable']){//if spot not avaliable
			$price = $spot['price'];
			if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],$price)){
				
				
			}
			else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price-0.5))){
				
				
			}
			else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price+0.5))){
				
				
			}
			else{
				echo"<h3>Sorry, your registered spot is currently taken and we could not find avialiable spot for your reserved period.<br/></h3>";
				exit;				
			}
			//if reassign success, need to update reservation database
			var_dump($spot);
			if (newEntrance($user,$garage_id,$spot['spot_id'],$reserve['beginTime'],$reserve['endTime'],$dbconnect)){
				mysqli_query($dbconnect,"UPDATE reservations SET valid=0, spot_id=".$spot['spot_id']." WHERE reserve_id=".$reserve['reserve_id']);
				echo"<h3>Sorry, your registered spot is currently unavaliable.<br/>
				Your new spot number is ".$spot['spotNum']."<br/>Entrance is provided.</h3>";
			}

		}
		else{//if spot avaliable
			
			if (newEntrance($user,$garage_id,$spot['spot_id'],$reserve['beginTime'],$reserve['endTime'],$dbconnect)){
				mysqli_query($dbconnect,"UPDATE reservations SET valid=0 WHERE reserve_id=".$reserve['reserve_id']);	
				echo"<h3>Your spot number is ".$spot['spotNum']."<br/>Entrance is provided.</h3>";
			}
		}

		exit;
	}
	else{//user has no avaliable reservation
		echo"No avaliable reservations found<br/>";


		$beginTime = date("y-m-d H:i:s",strtotime($currentTime."+30 minute"));
		$endTime = date("y-m-d H:i:s",strtotime($beginTime."+3 hour"));
		
		
		$price = 1;
		if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],$price)){
				
				
		}
		else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price-0.5))){
				
			
		}
		else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price+0.5))){
				
			
		}
		else{
			echo"No avaliable spots could be assigned now!";
			exit;			
		}		

		//var_dump($spot);
		if(newEntrance($user,$garage_id,$spot['spot_id'],$beginTime,$endTime,$dbconnect)){
			echo"<h3>Your spot number is ".$spot['spotNum']."<br/>Entrance is provided.</h3>";
		}
		exit;
	}
}
else if(isset($_GET['reserve_id'])){//access by confNumber


		$reserve = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM reservations WHERE reserve_id=".$_GET['reserve_id']));
		$user = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM users WHERE user_id=".$reserve['user_id']));
		if(isset($_GET['plateNum'])){
			$user['plateNum']=$_GET['plateNum'];
		}
		
		$spot = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id=".$reserve['spot_id']));
		
		if($spot['state']||$spot['disable']){//if spot not avaliable
			$price = $spot['price'];
			if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],$price)){
				
				
			}
			else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price-0.5))){
				
				
			}
			else if($spot = reassignSpot($dbconnect,$garage_id,$reserve['beginTime'],$reserve['endTime'],($price+0.5))){
				
				
			}
			else{
				echo"<h3>Sorry, your registered spot is currently taken and we could not find avialiable spot for your reserved period.<br/></h3>";
				exit;				
			}
			//if reassign success, need to update reservation database
			var_dump($spot);
			if (newEntrance($user,$garage_id,$spot['spot_id'],$reserve['beginTime'],$reserve['endTime'],$dbconnect)){
				mysqli_query($dbconnect,"UPDATE reservations SET valid=0, spot_id=".$spot['spot_id']." WHERE reserve_id=".$reserve['reserve_id']);
				echo"<h3>Sorry, your registered spot is currently unavaliable.<br/>
				Your new spot number is ".$spot['spotNum']."<br/>Entrance is provided.</h3>";
			}
		
		}
		else{//if spot avaliable

		
			if(newEntrance($user,$garage_id,$spot['spot_id'],$reserve['beginTime'],$reserve['endTime'],$dbconnect)){
				mysqli_query($dbconnect,"UPDATE reservations SET valid=0 WHERE reserve_id=".$reserve['reserve_id']);
				echo"<h3>Your spot number is ".$spot['spotNum']."<br/>Entrance is provided.<h3>";
			}
		}
		exit;
	
}
else{
	echo"<h3>ERROR: unknow user</h3>";
	exit;
	
}
?>