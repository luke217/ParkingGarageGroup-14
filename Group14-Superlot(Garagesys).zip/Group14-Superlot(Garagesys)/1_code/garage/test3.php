
<?php
date_default_timezone_set('America/New_York');
echo date('Y-m-d H:i:s');
?>