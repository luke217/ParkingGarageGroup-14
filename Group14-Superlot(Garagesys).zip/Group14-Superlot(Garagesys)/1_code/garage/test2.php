<?php
include('/garage/connect/dbconnect.php');
function createGarage($dbconnect,$name,$columnSize,$rowSize,$sectionSize,$singleSide=0){
	$garageSize = $columnSize*($rowSize+1)* $sectionSize;
	mysqli_query($dbconnect,
	"CREATE TABLE ".$name."(
		spot_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(spot_id),
		spotNum INT(4) NOT NULL,
		state BOOLEAN DEFAULT 0,
		disable BOOLEAN DEFAULT 0,
		price INT DEFAULT 0
	)");
	mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,sectionSize,garageSize,singleSide) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$sectionSize.",".$garageSize.",".$singleSide.")"
	);
	for($i=0;$i<$garageSize;$i++){
		mysqli_query($dbconnect,
		"INSERT INTO ".$name." (spotNum) VALUES (".($i+1000).")"
		);
		
	}
}

function drawSections($sectionLength,$sectionWidth,$sectionNum){
	for($i=0;$i<$sectionLength;$i++){
		echo"<tr>";
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		
		for($j=0;$j<$sectionNum;$j++){			
			echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
			if($sectionWidth==2){
				echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";				
			}
			echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		}
		
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
		echo"</tr>";
	}
	
}
function drawPassWay($width){
	echo"<tr>";
	for($i=0;$i<$width;$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";		
	}
	echo"</tr>";
}
function drawGarage($columnSize,$rowSize,$sectionSize,$singleSide=0){

	$sectionLength = $sectionSize/2;
	$sectionWidth = 2;
	if($singleSide==1 || $sectionSize%2==1) {
		$sectionLength = $sectionSize;
		$sectionWidth = 1;		
	}
	//draw entrance row
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"<td><a name = 'entrance' style = 'margin:0;border:0;padding:0'><img src='/garage/img/entrance.jpg' title= 'entrance'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
	for($i=1;$i<$columnSize;$i++){
		drawSections($sectionLength,$sectionWidth,$rowSize);
		drawPassWay($rowSize*($sectionWidth+1)+3);
	}
	drawSections($sectionLength,$sectionWidth,$rowSize);
	//draw exit row
	
	
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'exit' style = 'margin:0;border:0;padding:0'><img src='/garage/img/exit.jpg' title= 'exit'></a></td>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	echo"</table>";
}

function managerGarageState($dbconnect,$name){//manager interface check garage state
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));
	
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['columnSize'];
	$sectionSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	$singleSide = $garage['singleSide'];
	
	$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
	$s = mysqli_fetch_assoc($spots);
	drawGarage($columnSize,$rowSize,$squareSize,$singleSide);
	
	echo"<script>
			(function(){
			var spots = document.getElementsByName('spot');";

	for($i=0;$i<$garageSize;$i++){
		if($s['state']==1){
			echo'var c = spots['.$i.'].children; c[0].src="/garage/img/car.jpg";';
		}
		echo"spots[".$i."].setAttribute('data-spotid',".$i.");";
		echo"spots[".$i."].setAttribute('data-price',".$s['price'].");";
		echo"spots[".$i."].setAttribute('data-avaliability',".$s['disable'].");";
		echo"spots[".$i."].setAttribute('onclick','clickSpot(this)');";
		$s = mysqli_fetch_assoc($spots);
	}
	echo"})();
	function clickSpot(obj){
			document.getElementById('spotid').innerHTML = obj.getAttribute('data-spotid');			
			document.getElementById('price').innerHTML = obj.getAttribute('data-price');
			document.getElementById('disablebtn').style.display = 'initial';
			document.getElementById('setprice').style.display = 'initial';
			document.getElementById('newprice').style.display = 'initial';
			if(obj.getAttribute('data-avaliability')=='1'){
				document.getElementById('avaliability').value = 'Unavaliable';
				document.getElementById('disablebtn').value = 'enable';
			}
			else{
				document.getElementById('avaliability').value = 'Avaliable';				
				document.getElementById('disablebtn').value = 'disable';
			}
	}
	</script>";
}	
	
?>

<html>
<body>

<form action="setavaliability">
SpotId: <label id="spotid">56</label><br/>
<input id="avaliability" value = 'diabled' readonly>  <input type = "submit" id="disablebtn" value = "enable" style='display:none'><br/>
</form>
<form action="setprice">
Price: $<label id ="price">150</label><br/>
New Price:<input type = "textbox" id = "newprice" style="width:40px" style='display:none'>  <input type = "submit" id="setprice" value = "Set Price" style='display:none'>
</form>

<?php
mysqli_query($dbconnect,
	"CREATE TABLE reservations(
		reserve_id INT NOT NULL AUTO_INCREMENT,
		user_id INT NOT NULL,
		garage_id INT NOT NULL DEFAULT 1 ,
		spot_id INT(3) NOT NULL,
		confirmNum INT(10),
		PRIMARY KEY (reserve_id), 		
		FOREIGN KEY (garage_id) REFERENCES garages(garage_id), 
		FOREIGN KEY (user_id) REFERENCES users(user_id), 
		FOREIGN KEY (spot_id) REFERENCES spots(spot_id),
		beginTime DATETIME NOT NULL,
		endTime DATETIME NOT NULL
	) ENGINE=INNODB;");
//managerGarageState($dbconnect,"garage01");
?>


</body>
</html>