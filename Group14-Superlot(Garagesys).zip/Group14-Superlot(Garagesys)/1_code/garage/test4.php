<?php
//echo time()."<br>";

echo (time()%(3600*24*7))."<br/>";
echo (3600*24*7)."<br/>";
echo time();
//echo (microtime()*1000)."<br/>";
//echo (int)(1000000000+time()%(3600*24*7)*1000+(int)(microtime()*1000));
?>