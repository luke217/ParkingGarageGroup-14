<?php
$curTime = date("Y-m-d H:i:s");
echo $curTime;
$beginTime = date("Y-m-d H:i:s", strtotime($curTime."-".rand(1,10)."hour"));
echo"<br/>";
echo $beginTime;
?>