<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Superlot</title>

    <!-- Bootstrap -->
    <link href="/garage/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

 <body>
 <?php
   session_start();
  include('../../garage/connect/dbconnect.php');
  if((!isset($_SESSION['role']))||($_SESSION['role']!='customer')){
	header("location:/garage/index.php");
  }	  

  ?>
 <div class="container">


     

      <!-- Main component for a primary marketing message or call to action -->
	  <?php
	  include('../customer/navbar.php');
	  include('../whatsnew.php');
	  ?>
	 
	<div name='login' class="jumbotron">

	
	<?php
//session_start();

echo"<h3>Welcome</h3>";

  include('../connect/dbconnect.php');
      
  if(!isset($_SESSION['role'])){
    header('Location:/garage/index.php');
  }
  
$user_id = $_SESSION['user_id'];

if($_GET['action']=='gas'){
	$_GET['action']='gas station';
	
}
if($_GET['action']=='restaurant'){

  ?>
  <div type="button" style="border: 0; padding: 0; margin:0;background: transparent; position:relative;float:right; top:-50px;right: 0px">
  <a href="../garage/restaurant.php"><img src="restaurant1.jpg" style="float: left margin:0 0 10px 10px;"width="300" height="300" alt="button" /></a>
      </div>  
   <p style="font-size:18px">Mon  11:00 am - 10:00 pm<br> 
Tue 11:00 am - 10:00 pm<br>
Wed 11:00 am - 10:00 pm<br>
Thu 11:00 am - 10:00 pm<br>
Fri 11:00 am - 10:00 pm<br>
Sat 11:00 am - 10:00 pm<br> 
Sun 11:00 am - 10:00 pm<br>
 

      

</p>
  <?php    

    }
?>
 <?php
   if ($_GET['action']=='repair')
   {
   ?>
   <div type="button" style="border: 0; padding: 0; margin:0;background: transparent; position:relative;float:right; top:-50px;right: 0px">
  <a href="../garage/restaurant.php"><img src="repair1.png" style="float: left margin:0 0 10px 10px;"width="300" height="300" alt="button" /></a>
      </div>  
   <p style="font-size:18px">Mon  11:00 am - 10:00 pm<br> 
Tue 11:00 am - 10:00 pm<br>
Wed 11:00 am - 10:00 pm<br>
Thu 11:00 am - 10:00 pm<br>
Fri 11:00 am - 10:00 pm<br>
Sat 11:00 am - 10:00 pm<br> 
Sun 11:00 am - 10:00 pm<br>
 

      

</p>
<?php
    }
?>
<?php

$records = mysqli_query($dbconnect,"SELECT * FROM commercial WHERE type='".$_GET['action']."'");

//var_dump($records);
$record=mysqli_fetch_assoc($records);
  echo "<h4>".$record['name'].$record['address'].$record['telephone']."</h4><a href='https:/";
  echo "/".$record['weblink']."'><h4>   ".$record['weblink']. 
  "</h4></a><br/>";
 
  
//var_dump($record);
?>



  
    <style>
       #map {
        height: 400px;
        width: 100%;
       }
    </style>
 
  <div>
    <h3><?php
//	echo $_GET['action'];
	?> Map</h3>
    <div id="map"></div>
    <script>
      function initMap() {
        var uluru = {lat: <?php 

          echo $record['lat']?>, 
          lng: <?php
          echo $record['lng']

          ?>  };
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-ZTYC3nb4nJxMsXuFvCjwcx97xsnX6_o&callback=initMap">
    </script>
  </div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    </div> <!-- /container -->
	
	
	
	

	
 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="//assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/garage/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!--<script src="//assets/js/ie10-viewport-bug-workaround.js"></script>-->
  </body>

</html>
