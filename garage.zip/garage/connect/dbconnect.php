<?php
	$dbconnect = mysqli_connect("localhost","root","","garage");\
	
	date_default_timezone_set('America/New_York');
	
	if(mysqli_connect_errno()){
	echo"Connect failed:".mysqli_connect_error();
	exit;
	}
?>