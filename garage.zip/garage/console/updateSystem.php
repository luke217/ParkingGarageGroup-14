<?php
include('../../garage/connect/dbconnect.php');
$curTime = $_POST['curTime'];

$invalidReserveTime = date("Y-m-d H:i:s",strtotime($curTime.('-1hour')));
$upcomingReserveTime = date("Y-m-d H:i:s",strtotime($curTime.('+15 minute')));
$endingParkingTime = date("Y-m-d H:i:s",strtotime($curTime.('+15 minute')));

$invalidReserves = mysqli_query($dbconnect,"SELECT * FROM reservations WHERE beginTime < '".$invalidReserveTime."' AND valid = 1");
while($invalidReserve = mysqli_fetch_assoc($invalidReserves)){
	$duration = (strtotime($invalidReserve['endTime'])-strtotime($invalidReserve['beginTime']))/3600;
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id = ".$invalidReserve['garage_id']));

	$price = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id = ".$invalidReserve['spot_id']))['price'];
	
	
	$billing = $price * $duration;
	
	
	if(mysqli_query($dbconnect,"UPDATE users SET billing = billing+".$billing." WHERE user_id = ".$invalidReserve['user_id'])){
		echo"<h3>Billing Updated For user_id = ".$invalidReserve['user_id']."</h3>";		
	}
	if(mysqli_query($dbconnect,"UPDATE reservations SET valid = 0 WHERE reserve_id = ".$invalidReserve['reserve_id'])){
		echo"<h3>Set reserve_id = ".$invalidReserve['reserve_id']." To invalid</h3>";		
	}
}

$upComingReserves = mysqli_query($dbconnect,"SELECT * FROM reservations WHERE beginTime = '".$upcomingReserveTime."' AND valid = 1");
while($upComingReserve = mysqli_fetch_assoc($upComingReserves)){
	//send notifications
	echo"<h3>Upcoming Reservation Notification sent to user_id =".$upComingReserve['user_id']."</h3>";
}
//echo $endingParkingTime;
$endingParkings = mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE endTime = '".$endingParkingTime."'");
//var_dump($endingParkings);
//var_dump( mysqli_fetch_assoc($endingParkings));
while($endingParking = mysqli_fetch_assoc($endingParkings)){
	//send notifications
	echo"<h3>Ending ParkingTime Notification sent to user_id =".$endingParking['user_id']."</h3>";
}


?>