<?php
include('../garage/connect/dbconnect.php');
function createGarage($dbconnect,$name,$columnSize,$rowSize,$squareSize){
	$garageSize = $columnSize*($rowSize+1)* $squareSize;
	mysqli_query($dbconnect,
	"CREATE TABLE ".$name."(
		spot_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(spot_id),
		spotNum INT(4) NOT NULL,
		state BOOLEAN DEFAULT 0,
		disable BOOLEAN DEFAULT 0
	)");
	mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,squareSize,garageSize) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$squareSize.",".$garageSize.")"
	);
	for($i=0;$i<$garageSize;$i++){
		mysqli_query($dbconnect,
		"INSERT INTO ".$name." (spotNum) VALUES (".($i+1000).")"
		);
		
	}
}
function managerGarageState($dbconnect,$name){//manager interface check garage state, allow disable/enable the spot
}
function drawSections($sectionLength,$sectionWidth,$sectionNum){
	for($i=0;$i<$sectionLength;$i++){
		echo"<tr>";
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='../garage/img/empty_R.jpg' title= 'price'></a></td>";
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'price'></a></td>";		
		
		for($j=0;$j<$sectionNum;$j++){			
			echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='../garage/img/empty_L.jpg' title= 'price'></a></td>";
			if($sectionWidth==2){
				echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='../garage/img/empty_R.jpg' title= 'price'></a></td>";				
			}
			echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'price'></a></td>";		
		}
		
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='../garage/img/empty_L.jpg' title= 'price'></a></td>";
		echo"</tr>";
	}
	
}
function drawPassWay($width){
	echo"<tr>";
	for($i=0;$i<$width;$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";		
	}
	echo"</tr>";
}
function drawGarage($columnSize,$rowSize,$sectionSize,$singleSide=0){

	$sectionLength = $sectionSize/2;
	$sectionWidth = 2;
	if($singleSide==1 || $sectionSize%2==1) {
		$sectionLength = $sectionSize;
		$sectionWidth = 1;		
	}
	//draw entrance row
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"<td><a name = 'entrance' style = 'margin:0;border:0;padding:0'><img src='../garage/img/entrance.jpg' title= 'entrance'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
	for($i=1;$i<$columnSize;$i++){
		drawSections($sectionLength,$sectionWidth,$rowSize);
		drawPassWay($rowSize*($sectionWidth+1)+3);
	}
	drawSections($sectionLength,$sectionWidth,$rowSize);
	//draw exit row
	
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'exit' style = 'margin:0;border:0;padding:0'><img src='../garage/img/exit.jpg' title= 'exit'></a></td>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='../garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
}

function garageState($dbconnect,$name,$manager=0){//user/manager interface check garage state
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['columnSize'];
	$squareSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	
	$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
	$s = mysqli_fetch_assoc($spots);
	drawGarage($columnSize,$rowSize,$squareSize);
	echo"<script>
			(function(){
			var spots = document.getElementsByName('spot');";
	for($i=0;$i<$garageSize;$i++){
		if($s['state']==1){
			echo'var c = spots['.$i.'].children; c[0].src="img/car.jpg";';
		}
		echo"spots[".$i."].setAtrribute('data-spotid',".$i.");";
		echo"spots[".$i."].setAtrribute('data-price',".$s['price'].");";
		echo"spots[".$i."].setAtrribute('onclick','clickSpot(this)');";
		
		
		$s = mysqli_fetch_assoc($spots);
	}
	echo"})();
	function clickSpot(obj){
			document.getElementsById('spotid').innerHTML = obj.getAttribute('data-spotid');
	}
	</script>";
}
	
	
?>
<form action="setavaliability">
SpotId: <label id="spotid">56</label><br/>
<label id="disable">disabled</label>  <input type = "submit" id="disablebtn" value = "enable"><br/>
</form>
<form action="setprice">
Price: $<label id ="price">150</label><br/>
New Price:<input type = "textbox" id = "newprice" style="width:40px">  <input type = "submit" id="setprice" value = "Set Price">
</form>
<?php
garageState($dbconnect,"garage01",1);
?>