<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Superlot</title>

    <!-- Bootstrap -->
    <link href="/garage/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

 <body>
 <?php
  session_start();
  include('../../garage/connect/dbconnect.php');
  if(!isset($_SESSION['role'])){
	  header('Location:/garage/index.php');
  }
//  	  include('../../garage/customer/navbar.php');
  ?>
	  <?php
	  include('../customer/navbar.php');
	  ?>
	<div name='login' class="jumbotron">
		 <div class="container">

      <!-- Main component for a primary marketing message or call to action -->

	<div  class="jumbotron">
	<h3>Spots occupancy of Current Time</h3>
	 <?php
	  //$size = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT Count(*) as size FROM spots "))['size'];
	  
	  //$rowSize =10;
	  //$columSize = $size/10;
	  
	  $states = mysqli_query($dbconnect,"SELECT state FROM spots ");

	  ?>
	  <Table>
		<tr>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
		<a href="navigation.php"><img src="navbutton.gif" width="120" height="60" alt="button" /></a>
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="nav.jpg" width="360" height="60" alt="button" />
			</button>  
		</td> 
		</tr>
	  </Table>
	  <Table>
		<tr>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="80" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="entrance.jpg" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="160" height="60" alt="button" />
			</button>  
		</td> 
		
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="160" height="60" alt="button" />
			</button>  
		</td> 
		
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="80" height="60" alt="button" />
			</button>  
		</td> 
		</tr>
		</Table>
		
		<?php for($outerloop=0;$outerloop<3;$outerloop++){
		?>
		<?php for($innerloop=0;$innerloop<8;$innerloop++){
		?>
		<Table>
		<tr>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty.jpg" width="80" height="35" alt="button" />';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA.jpg" width="80" height="35" alt="button" />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="35" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty2.jpg" width="80" height="35" alt="button" />';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA2.jpg" width="80" height="35" alt="button"  />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB2.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC2.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty.jpg" width="80" height="35" alt="button"/>';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA.jpg" width="80" height="35" alt="button"  />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="35" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty2.jpg" width="80" height="35" alt="button" />';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA2.jpg" width="80" height="35" alt="button"  />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB2.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC2.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty.jpg" width="80" height="35" alt="button" />';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA.jpg" width="80" height="35" alt="button"  />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="35" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php 
			  if(!mysqli_fetch_assoc($states)['state']){
				  // $value = $spot.value;
			  echo'<img src="empty2.jpg" width="80" height="35" alt="button" />';//title="'.$value'" />';
			  }
			  else if($innerloop%3==0)
			  {
				   echo '<img src="carA2.jpg" width="80" height="35" alt="button"  />';
			  }
			else if($innerloop%3==1){
				 echo '<img src="carB2.jpg" width="80" height="35" alt="button"  />';
			  } 
			else if($innerloop%3==2){
				 echo '<img src="carC2.jpg" width="80" height="35" alt="button"  />';
			  }  
			 
			  ?>
		
			</button>  
		</td> 
		</tr>
		</Table>
		
		<?php
		}
		?>
		<Table>
		<tr>
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="80" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="160" height="60" alt="button" />
			</button>  
		</td> 
		
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="120" height="60" alt="button" />
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="160" height="60" alt="button" />
			</button>  
		</td> 
		
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<?php
			if($outerloop==2){
				echo '<img src="exit.jpg" width="120" height="60" alt="button" />';
				}
			else{
			echo '<img src="passway1.jpg" width="120" height="60" alt="button" />';
		}
		?>
			
			</button>  
		</td> 
		<td>
			<button type="button" style="border: 0; padding: 0; margin:0;background: transparent">
			<img src="passway1.jpg" width="80" height="60" alt="button" />
			</button>  
		</td> 
		</tr>
		</Table>
	<?php
		}
		?>
	  
      </div>
    </div> <!-- /container -->

	<!--
    <div class="container">
     Example row of columns
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
       </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      

      <footer>
        <p>&copy; 2016 Company, Inc.</p>
      </footer>
    </div> <!-- /container -->

 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="//assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/garage/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!--<script src="//assets/js/ie10-viewport-bug-workaround.js"></script>-->
  </body>
</html>
