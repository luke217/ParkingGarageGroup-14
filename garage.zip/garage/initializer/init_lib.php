<?php


 function SpotsAvaliability($dbconnect,$garage_id,$beginTime,$endTime){
	 return mysqli_query($dbconnect,"SELECT DISTINCT spot_id FROM reservations 
	 WHERE garage_id=".$garage_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' )) 
	 ORDER BY spot_id");
 }
 
 
 function reassignSpot($dbconnect,$garage_id,$beginTime,$endTime){
	 $spots = 	 SpotsAvaliability($dbconnect,$garage_id,$beginTime,$endTime);
	 $garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garage_id=".$garage_id));
	 while($spot = mysqli_fetch_assoc($spots)){
		 $s = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM ".$garage['garageName']." WHERE spot_id=".$spot['spot_id']));
		 if(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE garage_id = ".$garage_id." AND spot_id=".$spot['spot_id']))){
			continue;			 
		 }
		 if($s['state']==0&&$s['disable']==0){
			 return $s;
		 }
		 
	 }
	 return null;
	 
	 
	 
 }
 
function plateGenerator(){
	$p = "";
	for($i = 0;$i<6;$i++){
		if(rand(0,1)){
		
			$p=$p.chr(rand(65,90));
		}
		else{
			$p=$p.rand(0,9);
			
		}
	}
	return $p;
}
 function checkSpotAvaliability($dbconnect,$spot_id, $beginTime,$endTime){
	 $query  = "SELECT DISTINCT spot_id FROM reservations 
	 WHERE spot_id = ".$spot_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' ) ) ";
	 
	 if(mysqli_fetch_assoc(mysqli_query($dbconnect,$query)))return true;
	 return false;
	 
 }
 
function nameGenerator($length=0){
	$s = chr(rand(65,90));
	$l = $length? $length: rand(3,10);
	for($i=0;$i<$l;$i++){
		$s=$s.chr(rand(97,122));		
	}
	return $s;
}

function passWordGenerator(){
	$s = "";
	$l = rand(8,10);
	for($i=0;$i<$l;$i++){
		$s=$s.chr(rand(40,126));		
	}
	return $s;
}

function roundToNearestHalfHour($d){
		$date = date_create($d);
		$datestring = date_format($date,"y-m-d");
		$minute = date_format($date,"i");
		$hour = date_format($date,"H");
		if($minute<=30){
			return $datestring." ".$hour.":30:00";			
		}
		else {
			if($hour==23)//if hour is 23, needs to add one day
			{
				$date =date("y-m-d  H:i:s",strtotime($d.'+1 day')); 			
				return $date;
				
			}
			else{
				$hour++;
				return $datestring." ".$hour.":00:00";
			}
		}

	}

function addRandTime($time,$low,$high){//randomly add period 
	$ti = rand($low,$high);
	$time = $time.'+'.((int)($ti/2)).'hour';
	$time = $time.'+'.($ti%2*30).'minute';
	$newtime = date("y-m-d H:i:s",strtotime($time));
	return $newtime;
	}
	
function createGarage($dbconnect,$name,$columnSize,$rowSize,$sectionSize,$singleSide=0,$lat=NULL,$lng=NULL){
	$garageSize = $columnSize*($rowSize+1)* $sectionSize;
	mysqli_query($dbconnect,
	"CREATE TABLE ".$name."(
		spot_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(spot_id),
		spotNum INT(4) NOT NULL,
		state BOOLEAN DEFAULT 0,
		disable BOOLEAN DEFAULT 0,
		price FLOAT DEFAULT 0
	)");
	if($lat!=NULL && $lng!=NULL){
			mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,sectionSize,garageSize,singleSide,lat,lng) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$sectionSize.",".$garageSize.",".$singleSide.",".$lat.",".$lng.")"
	);

		
	}
	else{
	mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,sectionSize,garageSize,singleSide) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$sectionSize.",".$garageSize.",".$singleSide.")"
	);
	}
	for($i=0;$i<$garageSize;$i++){
		mysqli_query($dbconnect,
		"INSERT INTO ".$name." (spotNum) VALUES (".($i+1000).")"
		);
		
	}
}

function garageGenerator($dbconnect,$name,$col,$row,$sectionSize,$singleSide=0){	
	createGarage($dbconnect,$name,$col,$row,$sectionSize,$singleSide);
	//simulate current parking cars
	$garageSize = $col*($row+1)*$sectionSize;
		for($j=1;$j<=$garageSize;$j++){
			$state = 0;
			$disable=0;
			if(rand(1,10)<4){
				$state = 1;
			}		
			if(rand(1,100)==1){
				$disable=1;				
			}
			mysqli_query($dbconnect,"UPDATE ".$name." SET state=".$state.", disable=".$disable.", price=1  WHERE spot_id=".$j.";");
		}
}
function randomUserGenerator($userSize,$dbconnect){
	for($i=0;$i<$userSize;$i++){
		mysqli_query($dbconnect,"INSERT INTO users(firstName,lastName,username,password,plateNum)
		VALUES('".nameGenerator()."','".nameGenerator()."','".nameGenerator(10)."','".passWordGenerator()."','".plateGenerator()."');");
	}
}	
function parkingUserGenerator($dbconnect, $garageName,$userSize,$curTime){
	$garage_id = 1;
	$reservationSize = 0.5*$userSize;
	for($i=0;$i<$reservationSize;$i++){
		$beginTime = date("Y-m-d H:i:s", strtotime($curTime."-".rand(1,10)."hour"));
		$endTime = date("Y-m-d H:i:s", strtotime($curTime."+".rand(1,10)."hour"));
		$spot = reassignSpot($dbconnect,$garage_id,$beginTime,$endTime);
		$confNum = (int)(1000000000+time()%(3600*24*7)*1000+(int)(microtime()*1000));
		$user_id = $i+1;
		$plateNum = plateGenerator();
		mysqli_query($dbconnect,"INSERT INTO parkingusers (beginTime,plateNum,endTime,spot_id,garage_id, user_id) 
		VALUES ('".$beginTime."','".$plateNum."','".$endTime."',".$spot['spot_id'].",".$garage_id.",".$user_id.")");
		
		mysqli_query($dbconnect,"INSERT INTO reservations (beginTime,confirmNum,endTime,spot_id,garage_id, user_id,valid)
		VALUES ('".$beginTime."',".$confNum.",'".$endTime."',".$spot['spot_id'].",".$garage_id.",".$user_id." ,0);");
	}
	
}
function randomReserveGenerator($time,$garageName,$userSize,$dbconnect){
	
	$reservationSize = 0.7*$userSize;//assuming 70% of registered users currently have reservation
	for($i=0;$i<$reservationSize;$i++){
		$beginTime = addRandTime($time,1,40);
		$endTime = addRandTime($beginTime,2,40);
		$garageSize = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT garageSize FROM garages WHERE garagename = '".$garageName."';"))['garageSize'];
		$spotid =rand(1,$garageSize);
		
		$trial=0;

		//will get the available spot after loop
		//start making reservation
		$confNum = (int)(1000000000+time()%(3600*24*7)*1000+(int)(microtime()*1000));
		//confNum is generated as a conbination of Unix time and Unix microtime that garantees no repitition in a week
		
		mysqli_query($dbconnect,"INSERT INTO reservations (beginTime,confirmNum,endTime,spot_id,user_id)
		VALUES ('".$beginTime."',".$confNum.",'".$endTime."',".$spotid.",".rand(1,$userSize)." );");
		//then update the futurestate of the spots database
		//upDateSpots($spot,$time,$beginTime,$endTime,$dbconnect);
	}
}
function incomeGenerator($dbconnect){
	//generate past 
	$d = date("Y-m-d");
	for($i=0;$i<31;$i++){
		$year = date("Y",strtotime($d));
		$month = date("m",strtotime($d));
		$day = date("d",strtotime($d));
	mysqli_query($dbconnect,"INSERT INTO incomes (year, month, day, income) VALUES (".$year.",".$month.",".$day.",".rand(0,100).")");
		$d = date("Y-m-d",strtotime($d."-1 day"));
}
	
}
/*
function upDateSpots($spot,$currentTime,$beginTime,$endTime,$dbconnect){//upDateSpots is similar with checking availability
	$currentTime=strtotime($currentTime);
	$beginTime = strtotime($beginTime);
	$endTime = strtotime($endTime);
	$p1 = ($beginTime-$currentTime)/1800;
	$p2 = ($endTime-$currentTime)/1800;
	if($p1>32){//if both larger than 32, check second future state only
		$p1 = $p1-32;
		$p2 = $p2-32;
		$checkBits = ((1<<$p2)-1)&(1<<($p1-1));
		
		$spot['futurestate2'] = $spot['futurestate2']|$checkBits;
		
	}
	
	else if($p2>32){//if only p2 larger than 32, needs to check second future state
		$checkBits1 = (0-1)<<($p1-1);
		$checkBits2 = (1<<($p2-31)-1);
		$spot['futurestate1'] = $spot['futurestate1']|$checkBits1;
		$spot['futurestate2'] = $spot['futurestate2']|$checkBits2;
		
	}
	else{//check futurestate1 only
		$checkBits = ((1<<$p2)-1)&(1<<($p1-1));
		$spot['futurestate1'] = $spot['futurestate1']|$checkBits;	
	}
	
	mysqli_query($dbconnect,"UPDATE spots 
	SET futurestate1 = ".$spot['futurestate1'].",
	futurestate2 = ".$spot['futurestate2']."
	WHERE spot_id = '".$spot['spot_id']."';");
}

function checkSpotAvaliability($spot,$currentTime,$beginTime,$endTime){//all time needs to be rounded
	
	$currentTime=strtotime($currentTime);
	$beginTime = strtotime($beginTime);
	$endTime = strtotime($endTime);
	$p1 = ($beginTime-$currentTime)/1800;
	$p2 = ($endTime-$currentTime)/1800;
	if($p1>32){//if both larger than 32, check second future state only
		$p1 = $p1-32;
		$p2 = $p2-32;
		$checkBits = ((1<<$p2)-1)&(1<<($p1-1));
		if($checkBits&$spot['futurestate2']){//if result is 0, then available
			return false;
		}
		return true;			
	}
	
	else if($p2>32){//if only p2 larger than 32, needs to check second future state
		$checkBits1 = (0-1)<<($p1-1);
		$checkBits2 = (1<<($p2-31)-1);
		if( ($checkBits1&$spot['futurestate1'])|| ($checkBits2&$spot['futurestate2']) ){
			return false;
		}
		return true;
	}
	else{//check futurestate1 only
		$checkBits = ((1<<$p2)-1)&(1<<($p1-1));
		if($checkBits&$spot['futurestate1']){//if result is 0, then available
			return false;
		}
		return true;			
	}
}
*/

function tableGenerator($dbconnect){
	mysqli_query($dbconnect,
	 "CREATE TABLE users(
		user_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(user_id),
		firstName VARCHAR(10) NOT NULL ,
		lastName VARCHAR(10) NOT NULL ,
		username VARCHAR(40) NOT NULL UNIQUE,
		password VARCHAR(20) NOT NULL,
		plateNum CHAR(6) UNIQUE,
		phoneNum CHAR(10),
		role VARCHAR(10) NOT NULL DEFAULT 'customer',
		billing FLOAT DEFAULT 0
	)");
	mysqli_query($dbconnect,
	"CREATE TABLE garages(
		garage_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(garage_id),
		garageName VARCHAR(10) DEFAULT 'new_garage',
		columnSize INT NOT NULL,
		rowSize INT NOT NULL,
		sectionSize INT NOT NULL,
		garageSize INT NOT NULL,
		singleSide BOOLEAN DEFAULT 0,
		lat DOUBLE,
		lng DOUBLE
	)");
	
	mysqli_query($dbconnect,
	"CREATE TABLE reservations(
		reserve_id INT NOT NULL AUTO_INCREMENT,
		valid BOOLEAN DEFAULT 1,
		user_id INT NOT NULL,
		garage_id INT NOT NULL DEFAULT 1 ,
		spot_id INT(3) NOT NULL,
		confirmNum INT(10),
		PRIMARY KEY (reserve_id), 		
		FOREIGN KEY (garage_id) REFERENCES garages(garage_id), 
		FOREIGN KEY (user_id) REFERENCES users(user_id), 
		beginTime DATETIME NOT NULL,
		endTime DATETIME NOT NULL
	) ENGINE=INNODB;");
	mysqli_query($dbconnect,
	"CREATE TABLE parkingUsers(
		plateNum CHAR(6)NOT NULL UNIQUE,
		origin INT DEFAULT 0,
		user_id INT NOT NULL,
		garage_id INT NOT NULL DEFAULT 1 ,
		spot_id INT NOT NULL,
		PRIMARY KEY(user_id),		
		FOREIGN KEY (user_id) REFERENCES users(user_id),
		FOREIGN KEY (garage_id) REFERENCES garages(garage_id), 
		beginTime DATETIME NOT NULL,
		endTime DATETIME NOT NULL
	)");
	mysqli_query($dbconnect,
	"CREATE TABLE commercial(
		id INT NOT NULL AUTO_INCREMENT,
		name VARCHAR(30) NOT NULL,
		weblink VARCHAR(50),
		type VARCHAR(30) NOT NULL,
		address VARCHAR(100),
		telephone VARCHAR(15) NOT NULL,
		lat DOUBLE,
		lng DOUBLE,
		PRIMARY KEY(id)		
	)");
	
		mysqli_query($dbconnect,
	"CREATE TABLE incomes(
		year INT NOT NULL,
		month INT NOT NULL,
		day INT NOT NULL,
		income FLOAT NOT NULL
	)");
	mysqli_query($dbconnect,
	"CREATE TABLE reports(
		report_id INT NOT NULL AUTO_INCREMENT,
		user_id INT NOT NULL,
		garage_id INT NOT NULL DEFAULT 1 ,		
		plateNum CHAR(6)NOT NULL,
		spot_id INT NOT NULL,		
		time DATETIME NOT NULL,
		valid BOOLEAN DEFAULT 1
		
	)");
	mysqli_query($dbconnect,
	"CREATE TABLE parkingRecords(
		plateNum CHAR(6)NOT NULL,
		user_id INT NOT NULL,
		garage_id INT NOT NULL DEFAULT 1 ,
		spot_id INT NOT NULL,	
		FOREIGN KEY (user_id) REFERENCES users(user_id),
		FOREIGN KEY (garage_id) REFERENCES garages(garage_id), 
		beginTime DATETIME NOT NULL,
		endTime DATETIME NOT NULL,
		billing FLOAT 
		
	)");

	
}

?>