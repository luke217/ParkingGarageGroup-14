<?php
include("init_lib.php");
include("../connect/dbconnect.php");

$garageName= 'spots';
$userSize=60;//define amount of registered users
//$floorSize = 3;//define how many floors for registered users
$sectionCol=3;//define amount of spots in each floor
$sectionRow=2;
$sectionSize=16;

$time = roundToNearestHalfHour(date("y-m-d H:i:s"));


if(true){
tableGenerator($dbconnect);
echo"Tables Generated";
garageGenerator($dbconnect,$garageName,$sectionCol,$sectionRow,$sectionSize);
echo"Spots Initialized";
randomUserGenerator($userSize,$dbconnect);
echo "Users Initialized";
randomReserveGenerator($time,$garageName,$userSize,$dbconnect);

parkingUserGenerator($dbconnect, $garageName,$userSize,$time);
echo "reserevations Initialized";
incomeGenerator($dbconnect);
mysqli_query($dbconnect,"INSERT INTO users (username,plateNum,password) VALUES ('customer','CCCCCC','customer')");
mysqli_query($dbconnect,"INSERT INTO users (username,plateNum,password,role) VALUES ('manager','MMMMMM','manager','manager')");

mysqli_query($dbconnect,"INSERT INTO commercial (name,weblink,type,address,telephone,lat,lng) 
VALUES ('Sanctary','http://www.sanctuarynb.com/','restaurant','135 easton Ave, New Brunswick,nj','732-846-3393
',40.4997,-74.4553)");
mysqli_query($dbconnect,"INSERT INTO commercial (name,weblink,type,address,telephone,lat,lng) 
VALUES ('Exon','http://www.exxonmobilstations.com/532620-new-brunswick-exxon-new-brunswick','gas station','80 MEMORIAL PKWY
NEW BRUNSWICK, NEW JERSEY','7325454445',40.4837,-74.4196)");
mysqli_query($dbconnect,"INSERT INTO commercial (name,weblink,type,address,telephone,lat,lng) 
VALUES ('marks auto','http://www.1marksauto.com/','repair','580 Jersey Ave.New Brunswick,NJ','9992233523',40.5195,-74.5898)");

}

?>

