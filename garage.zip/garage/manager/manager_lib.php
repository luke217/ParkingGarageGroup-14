<?php
function drawSections($sectionLength,$sectionWidth,$sectionNum){
	for($i=0;$i<$sectionLength;$i++){
		echo"<tr>";
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		
		for($j=0;$j<$sectionNum;$j++){			
			echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
			if($sectionWidth==2){
				echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";				
			}
			echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		}
		
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
		echo"</tr>";
	}	
}

function drawPassWay($width){
	echo"<tr>";
	for($i=0;$i<$width;$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";		
	}
	echo"</tr>";
}

function drawGarage($columnSize,$rowSize,$sectionSize,$singleSide=0){

	$sectionLength = $sectionSize/2;
	$sectionWidth = 2;
	if($singleSide==1 || $sectionSize%2==1) {
		$sectionLength = $sectionSize;
		$sectionWidth = 1;		
	}
	//draw entrance row
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"<td><a name = 'entrance' style = 'margin:0;border:0;padding:0'><img src='/garage/img/entrance.jpg' title= 'entrance'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
	for($i=1;$i<$columnSize;$i++){
		drawSections($sectionLength,$sectionWidth,$rowSize);
		drawPassWay($rowSize*($sectionWidth+1)+3);
	}
	drawSections($sectionLength,$sectionWidth,$rowSize);
	//draw exit row
	
	
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'exit' style = 'margin:0;border:0;padding:0'><img src='/garage/img/exit.jpg' title= 'exit'></a></td>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	echo"</table>";
}

function managerGarageState($dbconnect,$name){//manager interface check garage state
	
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));
	
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['rowSize'];
	$sectionSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	$singleSide = $garage['singleSide'];
	echo "<div id='info'>";
	if($garage['lat']!=NULL && $garage['lat']!=NULL){
	?>
	<div id="map" style="height:200px;width:400px;float:right"></div>
	<script>
	function initMap() {
        var uluru = {lat: <?php 

          echo $garage['lat']?>, 
          lng: <?php
          echo $garage['lng']

          ?>  };
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-ZTYC3nb4nJxMsXuFvCjwcx97xsnX6_o&callback=initMap">
    </script>
	<?php
	}
	?>
	<form action='/garage/manager/index.php' method='post'>
SpotId: <input name="spot_id" id="spotid" style="width:65px" readonly>
<input hidden value = 'setavaliability' name='action'>
<input hidden name='garageName' value = '<?php
	echo $name;
?> '>
<input  name="avaliability" id="avaliability" hidden>  <input type = "submit" id="disablebtn" value = "Enable" style='display:none' class='btn btn-sm btn-primary' ><br/>
</form>

<form action='/garage/manager/index.php' method='post'>
<input hidden name='garageName' value = '<?php
	echo $name;
?> '>
<input hidden value = 'setprice' name='action'>
<input hidden name="spot_id" id="spotid2"> 
Price: $<label id ="price">150</label><br/>
New Price:<input type = "textbox" id = "newprice" name = "newprice" style="width:40px;display:none">  <input type = "submit" id="setprice" value = "Set Price" class='btn btn-sm btn-primary' style='display:none'>
</form>

		<?php
	
	$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
	$s = mysqli_fetch_assoc($spots);
	drawGarage($columnSize,$rowSize,$sectionSize,$singleSide);
	
	echo"<script>
			(function(){
			var spots = document.getElementsByName('spot');";

	for($i=0;$i<$garageSize;$i++){
		if($s['disable']==1){
			echo'var c = spots['.$i.'].children; c[0].src="/garage/img/disabled.jpg";';
		}

		if($s['state']==1){
			echo'var c = spots['.$i.'].children; c[0].src="/garage/img/car.jpg";';
		}
		echo"spots[".$i."].setAttribute('data-spotid',".$s['spot_id'].");";
		echo"spots[".$i."].setAttribute('data-price',".$s['price'].");";
		echo"spots[".$i."].setAttribute('data-avaliability',".$s['disable'].");";
		echo"spots[".$i."].setAttribute('onclick','clickSpot(this)');";
		$s = mysqli_fetch_assoc($spots);
	}
	echo"})();
	function clickSpot(obj){
			document.getElementById('spotid').value = obj.getAttribute('data-spotid');			
			document.getElementById('spotid2').value = obj.getAttribute('data-spotid');			
			document.getElementById('price').innerHTML = obj.getAttribute('data-price');
			document.getElementById('disablebtn').style.display = 'initial';
			document.getElementById('setprice').style.display = 'initial';
			document.getElementById('newprice').style.display = 'initial';
			if(obj.getAttribute('data-avaliability')=='1'){
				document.getElementById('avaliability').value = 'Unavaliable';
				document.getElementById('disablebtn').value = 'Enable';
			}
			else{
				document.getElementById('avaliability').value = 'Avaliable';				
				document.getElementById('disablebtn').value = 'Disable';
			}
	}
	</script>";
}	
	
	
	
function createGarage($dbconnect,$name,$columnSize,$rowSize,$sectionSize,$singleSide=0,$lat=NULL,$lng=NULL){
	$garageSize = $columnSize*($rowSize+1)* $sectionSize;
	mysqli_query($dbconnect,
	"CREATE TABLE ".$name."(
		spot_id INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(spot_id),
		spotNum INT(4) NOT NULL,
		state BOOLEAN DEFAULT 0,
		disable BOOLEAN DEFAULT 0,
		price FLOAT DEFAULT 0
	)");
	if($lat!=NULL && $lng!=NULL){
			mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,sectionSize,garageSize,singleSide,lat,lng) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$sectionSize.",".$garageSize.",".$singleSide.",".$lat.",".$lng.")"
	);

		
	}
	else{
	mysqli_query($dbconnect,
	"INSERT INTO garages (garageName,columnSize,rowSize,sectionSize,garageSize,singleSide) 
	VALUES ('".$name."',".$columnSize.",".$rowSize.",".$sectionSize.",".$garageSize.",".$singleSide.")"
	);
	}
	for($i=0;$i<$garageSize;$i++){
		mysqli_query($dbconnect,
		"INSERT INTO ".$name." (spotNum) VALUES (".($i+1000).")"
		);
		
	}
}


function garageStat($dbconnect,$name,$gradiant=20) {

	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));	
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['rowSize'];
	$sectionSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	$singleSide = $garage['singleSide'];

//echo"garage id=".$garage['garage_id'];
$sql = "SELECT COUNT(reserve_id) as frequency, spot_id
FROM reservations
WHERE garage_id=".$garage['garage_id']."
GROUP BY spot_id";

$maxSql = "SELECT MAX(x.frequency) as high FROM (".$sql.")x";

$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
$spotCounts = mysqli_query($dbconnect,$sql);



$max = mysqli_fetch_assoc(mysqli_query($dbconnect,$maxSql))['high'];
//echo "max is ".$max;

$s = mysqli_fetch_assoc($spots);
//echo " spot id="$spot['spot_id'];

$spotc = mysqli_fetch_assoc($spotCounts);
//echo " frequency =".$spotc['frequency'];
//echo " spot id=".$spotc['spot_id'];


$colorRange =$gradiant*$max;
if($colorRange>240)$colorRange=240;
$hue= 240;//adjust color difference
$sat = 75;
$lum = 60;

echo"<h3>SpotId: <label id='spotid'></label></h3>";
echo"<h3>Price: $ <label id ='price'></label></h3>";
echo"<br/><img src='/garage/img/colorbar.png'>";	
drawGarage($columnSize,$rowSize,$sectionSize,$singleSide);

echo"<script>
(function(){
	var spots = document.getElementsByName('spot');";
	

	for($i=0;$i<$garageSize;$i++){
		echo"spots[".$i."].innerHTML='<div></div>';";
		echo"spots[".$i."].children[0].style.width = '96px';";
		echo"spots[".$i."].children[0].style.height = '54px';";		
		echo"spots[".$i."].children[0].style.background = 'hsl(".$hue.",".$sat."%,".$lum."%)';";
		
		echo"spots[".$i."].setAttribute('onclick','clickSpot(this)');";
		echo"spots[".$i."].setAttribute('data-spotid',".$s['spot_id'].");";
		echo"spots[".$i."].setAttribute('data-price',".$s['price'].");";		
		if($s['spot_id']==$spotc['spot_id']){
			echo"spots[".$i."].children[0].style.background = 'hsl(".($hue-($spotc['frequency']/$max*$colorRange)).",".$sat."%,".$lum."%)';";			
			$spotc = mysqli_fetch_assoc($spotCounts);
		}
		$s = mysqli_fetch_assoc($spots);

	}

echo"
})();
function clickSpot(obj){
			document.getElementById('spotid').innerHTML = obj.getAttribute('data-spotid');			
			document.getElementById('price').innerHTML = obj.getAttribute('data-price');		
}
</script>";
}
?>