<?php
if(isset($_POST['action'])&&($_POST['action']=='adduser')){
	if(isset($_POST['username'])){
		if($_POST['password'] != $_POST['confirmpassword']){
			echo"<h2>Two password does not match!</h2>";
		}
		else{
			$userNameCheck=mysqli_query($dbconnect,"SELECT * FROM user_account WHERE username='".$_POST['username']."'");
			$plateNumCheck=mysqli_query($dbconnect,"SELECT * FROM user_account WHERE plateNum='".$_POST['plateNum']."'");
			if(mysqli_fetch_assoc($userNameCheck)){
				
				echo "<h2>The username already exist</h2>";

				

			}
			else if(mysqli_fetch_assoc($plateNumCheck)){
				echo "<h2>This Licence Plate is already registered</h2>";
			}
			else{
				$sql="INSERT INTO users (firstName, lastName,username,password,plateNum,phoneNum )
				  VALUES('".$_POST['firstName']."','".$_POST['lastName']."','".$_POST['username']."','".$_POST['password']."','".$_POST['plateNum']."','".$_POST['phoneNum']."')";
				if(mysqli_query($dbconnect,$sql)){
					echo"<h2>successfully create account</h2>";				
					}
				else{
					echo "<h2>account creation failed </h2>";
				} 
			}       
		}
	}

	
}
else{	
	
	 
?>
<h3>Create New Account</h3>
<form class="form" action="/garage/index.php" method="post" >
      <input hidden name="action" value = 'adduser'/>	   
 <div class="form-group">
    <label for="firstName">First Name</label>
          <input type="text"  name="firstName" id="firstName" required />
 </div>
<div class="form-group">
		<label for="lastName">Last Name</label>
        <input type="text"  name="lastName" id="lastName" required />
 </div>
<div class="form-group">
    <label for="username">Username</label>
    <input type="text"  name="username" id="username" required />
 </div>
<div class="form-group">
    <label for="password">Password</label>
          <input type="text" name="password" id="password" required />
 </div>
<div class="form-group">
    <label for="plateNum">Plate Number</label>
          <input type="text" style="text-transform:uppercase" maxlength='6'  name="plateNum" id="plateNum" required />
 </div>
 <div class="form-group">
    <label for="phoneNum">Phone Number</label>
          <input type="text"  name="phoneNum" id="phoneNum" required />
 </div>
 
  <button type="submit" class="btn btn-default">Create New Account</button>
</form>

   
	<?php
}
	?>