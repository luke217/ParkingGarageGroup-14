<?php
include("manager_lib.php");
if(isset($_GET['garageName'])){
		garageStat($dbconnect,$_GET['garageName'],200);
	
}
else{
	$result=mysqli_query($dbconnect,'SELECT garageName FROM garages');

	echo"<form action='/garage/manager/index.php' method='get'>
		<input hidden value = 'statistic' name='action'>";
	echo"Select the garage you want to check:<select name='garageName'>";
	while($garagName = mysqli_fetch_assoc($result)['garageName'])
	{
		echo"<option>".$garagName."</option>";
	}
	echo"</selet><input type='submit' value = 'Check Garage Statistic' class='btn btn-primary'></form>";
	echo"<a class='btn btn-default' href =/garage/manager/index.php?action=graph>View Income Stat</a>";
}

?>