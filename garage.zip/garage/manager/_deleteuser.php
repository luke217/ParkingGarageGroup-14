<?php
	if(isset($_GET['user_id'])){
		while(mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM reservations WHERE user_id=".$_GET['user_id']))){
			
			mysqli_query($dbconnect,"DELETE FROM reservations WHERE user_id=".$_GET['user_id']);
		}
		if(mysqli_query($dbconnect,"DELETE FROM users WHERE user_id=".$_GET['user_id'])){
			echo "<h2>Successfully delete account with user id=".$_GET['user_id']."!</h2>";			

		}
		else{
			echo "<h2>Failed to delete user !</h2>";		
			
		}
		
		
		
	}
	else{
		echo "<h2>user id not provided!</h2>";
		
	}
	
	
	 
?>