<?php
include("manager_lib.php");
if(isset($_POST['action'])&&($_POST['action']=='createGarage')){
	
	$nameCheck = mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$_POST['garageName']."'");	
	
	if(mysqli_fetch_assoc($nameCheck)){
		echo"a garage with the same name already exits";
	}
	else{
		if(isset($_POST['lat'])&&isset($_POST['lng'])){
			createGarage($dbconnect,$_POST['garageName'],$_POST['columnSize'],$_POST['rowSize'],$_POST['sectionSize'],$_POST['singleSide'],$_POST['lat'],$_POST['lng']);
			echo "<h2>Garage Creation Success</h2>";
			drawGarage($_POST['columnSize'],$_POST['rowSize'],$_POST['sectionSize'],$_POST['singleSide']);
		}
		else{
			createGarage($dbconnect,$_POST['garageName'],$_POST['columnSize'],$_POST['rowSize'],$_POST['sectionSize'],$_POST['singleSide']);
			echo "<h2>Garage Creation Success</h2>";
			drawGarage($_POST['columnSize'],$_POST['rowSize'],$_POST['sectionSize'],$_POST['singleSide']);			
			
		}
	}
}
else{
?>
<script>
function check(){
	var c = document.getElementById('check');
	if(c.checked){
		document.getElementById('singleSide').value = 1;
	}
	else{
		document.getElementById('singleSide').value = 0;		
	}
}
</script>
<form action='/garage/manager/index.php' method='post'>

		<div id='locpick' style="float:right;visibility:hidden">
	<?php
		include('locpick.php');
	?>
	</div>

	<table>	
	<tr>
		<td>Garage Name:</td>
		<td>
			<input name='garageName' required>
		</td>
	</tr>	
	<tr>
		<td>
			Garage Dimension
		</td>
	</tr>
	<tr>
		<td>
			Size of each Section:
		</td>
		<td>
			<input name= 'sectionSize' required> spots<br/>
			<input type= 'checkbox' id='check' onchange="(function(){
				if(this.checked){document.getElementById('singleSide').value = 1;}
				else{document.getElementById('singleSide').value = 0;}
				}).call(this)" >
			Singleside
		</td>

	</tr>
	<tr>
		<td>
			Number of sections in a column:
		</td>
		<td>
			<input name= 'columnSize' required>sections
		</td>
	</tr>
	<tr>
		<td>
			Number of sections in a row:
		</td>
		<td>
			<input name= 'rowSize' required>sections
		</td>
	</tr>
	<tr>
	<td>
	<a onclick = "locpick(this)" >Set Garage Position</a>
	</td>
	<tr>
	</table>
	<br/>
	<input type='submit' value = 'Create Garage' class='btn btn-lg btn-primary'>
	<input hidden value = 'createGarage' name='action' >	
	<input hidden name = 'singleSide' id='singleSide' value=0>
</form>
<script>
function locpick(obj){
	document.getElementById('locpick').style.visibility='visible';
	obj.hidden='hidden';
	var c1=document.createElement('td');
	c1.innerHTML="Click on a location on the map to select position of garage <input style = 'visibility:hidden' name='lat' id='lat'><br/><input style = 'visibility:hidden' name='lng' id='lng'>";

	obj.parentElement.appendChild(c1);

	}
</script>
<?php
}
?>