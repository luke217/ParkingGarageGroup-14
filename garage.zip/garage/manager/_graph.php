<?php
//            date_default_timezone_set('UTC');
					
  //          echo "Today is " . date("Y.m.d") . "<br>";
            $day_range = intval(date("d"));    // $day_range = 22;
            $year = intval(date("Y"));         // $year = 2017
            
            
    
            // pass a week's income
            $week_days = 6;
            
            $week_income = array();
   
            while($week_days>=0){
                $the_day_income = array();
                $month = intval(date("m"));
                $day = $day_range-$week_days;   // $day = 15;
                
                if ($day<=0)
                {
                    $month = $month-1;
                    if ($month<1)
                    {
                        $month = 12;
                        $year = $year-1;
                    }
                    switch ($month) {
                        case 1:
                            $day = 31+$day;   
                            break;
                        case 3:
                            $day = 31+day;
                            break;
                        case 5:
                            $day = 31+$day;
                            break;
                        case 7:
                            $day = 31+$day;
                            break;
                        case 8:
                            $day = 31+$day;
                            break;
                        case 10:
                            $day = 31+$day;
                            break;
                        case 12:
                            $day = 31+$day;
                            break;
                        case 4:
                            $day = 30+$day;
                            break;
                        case 6:
                            $day = 30+$day;
                            break;
                        case 9:
                            $day = 30+$day;
                            break;
                        case 11:
                            $day = 30+$day;
                            break;
                        case 2:
                            $day = 28+$day;
                            if ($year%4 == 0)
                                $day = 29+$day;
                            break;
                        default:
                            break;
                    }
                }
                
                $result = mysqli_query($dbconnect,"SELECT income FROM incomes WHERE month = ".$month." AND day=".$day." AND year = ".$year);
                while($t=mysqli_fetch_assoc($result)){
                    $the_day_income[] = $t["income"];  
                }
                $week_income[] = array_sum($the_day_income);
                $week_days = $week_days - 1;
            }
                
                // pass a month's profit
                $month_days = 30; 
                
                $month_income = array();
    
                while($month_days>=0){
                $month = intval(date("m"));
                $day = $day_range-$month_days;   // $day = 15;
                $the_day_income = array();
                    
                if ($day<=0)
                {
                    $month = $month-1;
                    if ($month<1)
                    {
                        $month = 12;
                        $year = $year-1;
                    }
                    switch ($month) {
                        case 1:
                            $day = 31+$day;   // $day is negative, 31+$day = 31 - the number  
                            break;            //  of days
                        case 3:
                            $day = 31+$day;
                            break;
                        case 5:
                            $day = 31+$day;
                            break;
                        case 7:
                            $day = 31+$day;
                            break;
                        case 8:
                            $day = 31+$day;
                            break;
                        case 10:
                            $day = 31+$day;
                            break;
                        case 12:
                            $day = 31+$day;
                            break;
                        case 4:
                            $day = 30+$day;
                            break;
                        case 6:
                            $day = 30+$day;
                            break;
                        case 9:
                            $day = 30+$day;
                            break;
                        case 11:
                            $day = 30+$day;
                            break;
                        case 2:
                            $day = 28+$day;
                            if ($year%4 == 0)
                                $day = 29+$day;
                            break;
                        default:
                            break;
                    }
                }
                
                $result = mysqli_query($dbconnect,"SELECT income FROM incomes WHERE month = '$month' AND day='$day' AND year = '$year'");
                while($t=mysqli_fetch_assoc($result)){
                    $the_day_income[] = $t["income"];  
                }
                $month_income[] = array_sum($the_day_income);
                  //  echo array_sum($the_day_income);
                $month_days = $month_days - 1;
                
                
            }
    
            
            ?>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var week_incomes = <?php echo json_encode($week_income);?>;


            var data = google.visualization.arrayToDataTable([
                ['Month', 'Sales'],
                ['Day1', week_incomes[0]],
                ['Day2', week_incomes[1]],
                ['Day3', week_incomes[2]],
                ['Day4', week_incomes[3]],
                ['Day5', week_incomes[4]],
                ['Day6', week_incomes[5]],
                ['Today', week_incomes[6]]

            ]);

            var options = {
                title: 'Last 7 Days Profit ',
                legend: {
                    position: 'bottom'
                }
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

            chart.draw(data, options);
        }

    </script>


    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            var month_incomes = <?php echo json_encode($month_income);?>;


            var data = google.visualization.arrayToDataTable([
                ['Month', 'Sales'],
                ['The Previous Month', month_incomes[0]],
                ['', month_incomes[1]],
                ['', month_incomes[2]],
                ['', month_incomes[3]],
                ['', month_incomes[4]],
                ['', month_incomes[5]],
                ['', month_incomes[6]],
                ['', month_incomes[7]],
                ['', month_incomes[8]],
                ['', month_incomes[9]],
                ['', month_incomes[10]],
                ['', month_incomes[11]],
                ['', month_incomes[12]],
                ['', month_incomes[13]],
                ['', month_incomes[14]],
                ['', month_incomes[15]],
                ['', month_incomes[16]],
                ['', month_incomes[17]],
                ['', month_incomes[18]],
                ['', month_incomes[19]],
                ['', month_incomes[20]],
                ['', month_incomes[21]],
                ['', month_incomes[22]],
                ['', month_incomes[23]],
                ['', month_incomes[24]],
                ['', month_incomes[25]],
                ['', month_incomes[26]],
                ['', month_incomes[27]],
                ['', month_incomes[28]],
                ['', month_incomes[29]],
                ['', month_incomes[30]],
                ['', month_incomes[31]]

            ]);

            var options = {
                title: 'Last 31 Days Profit',
                legend: {
                    position: 'bottom'
                }
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart_month'));

            chart.draw(data, options);
        }

    </script>


    <center>
        <div id="curve_chart" style="width: 900px; height: 500px"></div>
        <br>
        <div id="curve_chart_month" style="width: 1000px; height: 500px"></div>
    </center>

