<?php

	echo"<table class='table table-striped table-hover'>";
	echo"<tr><td><h4>User ID</h4></td><td><h4>Plate Number</h4></td><td><h4>Garage ID</h4></td><td><h4>Spot ID</h4></td><td><h4>Begin Time</h4></td><td><h4>EndTime</h4></td><td></td></tr>";	
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$_POST['garageName']."'"));
	//var_dump($garage);
	$users = mysqli_query($dbconnect,"SELECT * FROM parkingusers WHERE garage_id = ".$garage['garage_id']." ORDER BY beginTime");
	//var_dump($users);
	while($user = mysqli_fetch_assoc($users)){
	//var_dump($user);
		echo"<tr><td><a href = '/garage/manager/index.php?action=userInfo&user_id=".$user['user_id']."'>".$user['user_id']."</a></td><td>".$user['plateNum']."</td><td>".$user['garage_id']."</td><td>".$user['spot_id']."</td><td>".$user['beginTime']."</td><td>".$user['endTime']."</td></tr>";
	}
	echo"</table>";

	
	
	 
?>