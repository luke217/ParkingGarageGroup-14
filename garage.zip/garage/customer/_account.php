
<?php
$user = mysqli_fetch_assoc(mysqli_query($dbconnect,'SELECT * FROM users WHERE user_id='.$_SESSION['user_id']));
echo"<h3>".$user['firstName']." ".$user['lastName']."</h3>";
echo"</br>Email/Username: ".$user['username'];
echo"</br>License Plate: ".$user['plateNum'];
echo"</br>Phone:".$user['phoneNum'];
echo"</br>Billing:".$user['billing']."<a class='btn btn-default' href='/garage/customer/index.php?action=pay'>Make a payment</a>"

?>
<br/>
<br/>
<a class='btn btn-primary' href='/garage/customer/index.php?action=editInfo'>Change Account Information</a>
<!--
<form action="/garage/customer/index.php" method='post'>
<input hidden value = 'editInfo' name='action'>
<input type='submit' value = 'Edit' class='btn btn-lg btn-primary'>
</form>
-->
