<?php

function drawSections($sectionLength,$sectionWidth,$sectionNum){
	for($i=0;$i<$sectionLength;$i++){
		echo"<tr>";
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		
		for($j=0;$j<$sectionNum;$j++){			
			echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
			if($sectionWidth==2){
				echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_R.jpg' title= 'price'></a></td>";				
			}
			echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'price'></a></td>";		
		}
		
		echo"<td><a name = 'spot' style = 'margin:0;border:0;padding:0'><img src='/garage/img/empty_L.jpg' title= 'price'></a></td>";
		echo"</tr>";
	}
	
}
function drawPassWay($width){
	echo"<tr>";
	for($i=0;$i<$width;$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";		
	}
	echo"</tr>";
}
function drawGarage($columnSize,$rowSize,$sectionSize,$singleSide=0){

	$sectionLength = $sectionSize/2;
	$sectionWidth = 2;
	if($singleSide==1 || $sectionSize%2==1) {
		$sectionLength = $sectionSize;
		$sectionWidth = 1;		
	}
	//draw entrance row
	echo"<table style= 'background-color:gray'>";
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"<td><a name = 'entrance' style = 'margin:0;border:0;padding:0'><img src='/garage/img/entrance.jpg' title= 'entrance'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	
	for($i=1;$i<$columnSize;$i++){
		drawSections($sectionLength,$sectionWidth,$rowSize);
		drawPassWay($rowSize*($sectionWidth+1)+3);
	}
	drawSections($sectionLength,$sectionWidth,$rowSize);
	//draw exit row
	
	
	echo"<tr>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	for($i=0;$i<($rowSize*($sectionWidth+1));$i++){
		echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	}
	echo"<td><a name = 'exit' style = 'margin:0;border:0;padding:0'><img src='/garage/img/exit.jpg' title= 'exit'></a></td>";
	echo"<td><a name = 'passway' style = 'margin:0;border:0;padding:0'><img src='/garage/img/passway.jpg' title= 'passway'></a></td>";
	echo"</tr>";
	echo"</table>";
}

 function SpotsAvaliability($dbconnect,$garage_id,$beginTime,$endTime){
	 return mysqli_query($dbconnect,"SELECT DISTINCT spot_id FROM reservations 
	 WHERE garage_id=".$garage_id." AND ((beginTime < '".$beginTime."' AND endTime >= '".$beginTime."') OR (beginTime > '".$beginTime."' AND beginTime <= '".$endTime."' )) 
	 ORDER BY spot_id");
	 
 }

function customerGarageState($dbconnect,$name){//user interface check garage state, allow disable/enable the spot
	
	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));	
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['rowSize'];
	$sectionSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	$singleSide = $garage['singleSide'];
	
	$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
	$s = mysqli_fetch_assoc($spots);
		if($garage['lat']!=NULL && $garage['lat']!=NULL){
	?>
	<div id="map" style="height:200px;width:400px;float:right"></div>
	<script>
	function initMap() {
        var uluru = {lat: <?php 

          echo $garage['lat']?>, 
          lng: <?php
          echo $garage['lng']

          ?>  };
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-ZTYC3nb4nJxMsXuFvCjwcx97xsnX6_o&callback=initMap">
    </script>
<?php
		}
		echo "Spot Number: <label id='spotNum'></label><br/>
		 Price: $<label id ='price'></label><br/>";
		 	drawGarage($columnSize,$rowSize,$sectionSize,$singleSide);
	
	

	
		echo"<script>
				(function(){
				var spots = document.getElementsByName('spot');";

		for($i=0;$i<$garageSize;$i++){
			if($s['disable']){
				echo'var c = spots['.$i.'].children; c[0].src="/garage/img/disabled.jpg";';				
			}			
			if($s['state']==1){
				echo'var c = spots['.$i.'].children; c[0].src="/garage/img/car.jpg";';
			}
			echo"spots[".$i."].setAttribute('data-spotNum',".$s['spotNum'].");";
			echo"spots[".$i."].setAttribute('data-price',".$s['price'].");";
			echo"spots[".$i."].setAttribute('onclick','clickSpot(this)');";
			$s = mysqli_fetch_assoc($spots);
		}
		echo"})();
		function clickSpot(obj){
				document.getElementById('spotNum').innerHTML = obj.getAttribute('data-spotNum');			
				document.getElementById('price').innerHTML = obj.getAttribute('data-price');
		}
		</script>";

}

 function roundToNearestHalfHour($d){
		if($d==NULL)return NULL;
		
		$date = date_create($d);
		$datestring = date_format($date,"y-m-d");
		$minute = date_format($date,"i");
		$hour = date_format($date,"H");
		if($minute<15){
			return $datestring." ".$hour.":00:00";
		}
		else if($minute>45){
			if($hour==23)//if hour is 23, needs to add one day
			{
				return date("y-m-d H:i:s",strtotime($datestring.'+1 day'));
				
			}
			else{
				$hour++;
				return $datestring." ".$hour.":00:00";
			}
		}
		else{
			return $datestring." ".$hour.":30:00";			
		}
}
	
function reserveGarageState($dbconnect,$name,$beginTime,$endTime){//user interface check garage state, allow disable/enable the spot

	$garage = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName = '".$name."'"));	
	$columnSize = $garage['columnSize'];
	$rowSize = $garage['rowSize'];
	$sectionSize = $garage['sectionSize'];
	$garageSize = $garage['garageSize'];
	$singleSide = $garage['singleSide'];
	
	$spots =  mysqli_query($dbconnect,"SELECT * FROM ".$name);
	$s = mysqli_fetch_assoc($spots);
	echo"<h3>Spot Number:</h3> <h3 id='spotNum'></h3><br/>
		 <h3>Price:</h3><h3 id ='price'></h3><br/>
		 <form action='/garage/customer/index.php' method='post'>
		<input hidden value = 'confirmReserve' name='action'>
		<input hidden value = '".$beginTime."' name='beginTime' id='beginTime'>
		<input hidden value = '".$endTime."' name='endTime'	  id='endTime'>
		<input hidden value = '' name='spot_id'   id='spot_id'>
		<input hidden value = ".$garage['garage_id']." name='garage_id'>
		<input type='submit' id='submit' value = 'Reserve This Spot' class='btn btn-lg btn-primary' style='visibility:hidden'>
		</form>";
		 
	drawGarage($columnSize,$rowSize,$sectionSize,$singleSide);
	
	$redSpots = SpotsAvaliability($dbconnect,$garage['garage_id'],date("Y-m-d H:i:s", strtotime($beginTime."+30 minute")),date("Y-m-d H:i:s", strtotime($beginTime."+30 minute")));
	$redSpotId = mysqli_fetch_assoc($redSpots)['spot_id'];
	
	echo"<script>
				(function(){
				var spots = document.getElementsByName('spot');";

		for($i=0;$i<$garageSize;$i++){
			if($s['disable']){
				echo'var c = spots['.$i.'].children; c[0].src="/garage/img/disabled.jpg";';				
			}
			else if($s['spot_id']==$redSpotId){
				echo'var c = spots['.$i.'].children; c[0].src="/garage/img/car.jpg";';
				$redSpotId = mysqli_fetch_assoc($redSpots)['spot_id'];
			}
			else{
				echo"spots[".$i."].setAttribute('data-spotNum',".$s['spotNum'].");";
				echo"spots[".$i."].setAttribute('data-spotid',".$s['spot_id'].");";
				echo"spots[".$i."].setAttribute('data-price',".$s['price'].");";
				echo"spots[".$i."].setAttribute('onclick','clickSpot(this)');";
				
			}
			$s = mysqli_fetch_assoc($spots);
		}
		echo"})();
		function clickSpot(obj){
				document.getElementById('submit').style.visibility = 'visible';
				document.getElementById('spotNum').innerHTML = obj.getAttribute('data-spotNum');							
				document.getElementById('price').innerHTML = '$'+obj.getAttribute('data-price');
				document.getElementById('spot_id').value = obj.getAttribute('data-spotid');
		}
		</script>";
}

?>
