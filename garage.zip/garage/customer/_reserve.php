<?php
include("customer_lib.php");
include("timePicker.php");
if(isset($_POST['action'])){
	if($_POST['action']=='checkReserveGarage'){

		$garage_id = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM garages WHERE garageName='".$_POST['garageName']."'"))['garage_id'];

		if(($_POST['garageName']==NULL)||($_POST['beginTime']==NULL)||($_POST['beginTime']==NULL)){
			header('location: /garage/customer/index.php');
		}
		else if((strtotime($_POST['beginTime'])-strtotime(date("y-m-d H:i:s")))<1800){
		echo "Reservation duration not acceptible: the begin time must be at least 30 minutes later";
		}
		else if((strtotime($_POST['endTime'])-strtotime($_POST['beginTime']))<7200){
			echo "Reservation duration not acceptible: the reservation duration must be at least 2 hours";
		}
		else if(mysqli_fetch_assoc(			mysqli_query($dbconnect,"SELECT DISTINCT spot_id FROM reservations 
	 WHERE user_id=".$_SESSION['user_id']." AND garage_id=".$garage_id." AND ((beginTime < '".$_POST['beginTime']."' AND endTime >= '".$_POST['beginTime']."') OR (beginTime > '".$_POST['beginTime']."' AND beginTime <= '".$_POST['endTime']."' )) 
	 ORDER BY spot_id"))){
			

			echo "You already have a reservation that is conflict with this time duration";
		}		
		else{
			

			reserveGarageState($dbconnect,$_POST['garageName'],$_POST['beginTime'],$_POST['endTime']);

		}			
	}
	else if($_POST['action']=='confirmReserve'){

			if(($_POST['garage_id']==NULL)||($_POST['beginTime']==NULL)||($_POST['beginTime']==NULL)||($_POST['spot_id']==NULL)){
				header('location: /garage/customer/index.php?action=reserve');
			
			}
			else if((strtotime($_POST['beginTime'])-strtotime( date("y-m-d H:i:s")))<1800){
				echo "Reservation duration not acceptible: the begin time must be at least 30 minutes later";			
			}
			else if((strtotime($_POST['endTime'])-strtotime($_POST['beginTime']))<7200){
					echo "Reservation duration not acceptible: the reservation duration must be at least 2 hours";
			}	
			else{

				
				$confNum = (int)(1000000000+time()%(3600*24*7)*1000+(int)(microtime()*1000));
													//var_dump($_POST);
				$f= mysqli_query($dbconnect,"INSERT INTO reservations (garage_id,beginTime,confirmNum,endTime,spot_id,user_id)
				VALUES (".$_POST['garage_id'].",'".$_POST['beginTime']."',".$confNum.",'".$_POST['endTime']."',".$_POST['spot_id'].",".$_SESSION['user_id']." );");
				if($f){		
					echo "<h4>Reservation success<br/> Your confirmation number is ".$confNum."</h4>";
					$user = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM users WHERE user_id=".$_SESSION['user_id'] ));
							if($user['phoneNum']!=NULL){
								ini_set("SMTP", "ssl:smtp.gmail.com");
								ini_set("smtp_port", "465");
								$to       = $user['phoneNum'].'@tmomail.net';
								$subject  = 'Reservation Confirmation';
								$message  = 'You have successfully made a reservation, the confirmation number is'.$confNum;
								$headers  = 'From: superlot14@gmail.com' . "\r\n" .
											'MIME-Version: 1.0' . "\r\n" .
											'Content-type: text/html; charset=utf-8';
								if(mail($to, $subject, $message, $headers))
									echo "Email sent";
								else
									echo "Email sending failed";
								
							}
				}
				else{
					echo "<h4>Reservation failed</h4>";
		
				}
			}		
	}	
}
?>
