<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Superlot</title>

    <!-- Bootstrap -->
    <link href="/garage/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

 <body>
 <?php
   session_start();
  include('../../garage/connect/dbconnect.php');
  if((!isset($_SESSION['role']))||($_SESSION['role']!='customer')){
	header("location:/garage/index.php");
  }	  

  ?>
  <div class="container-fluid"style="background-image: url('/garage/img/background.jpg');
                              background-repeat: no-repeat;
                              -webkit-background-size: cover;
                              -moz-background-size: cover;
                              -o-background-size: cover;
                               background-size: cover;
                              margin-right:auto;
                              margin-left:auto;
                              height:689px;
							  width:1000px;
                              opacity: 0.85;
                              filter: alpha(opacity=90);">

asdfsaf
     

      <!-- Main component for a primary marketing message or call to action -->
	  <?php
	  include('navbar.php');
	  include('../whatsnew.php');
	  ?>
<div name='login' class="jumbotron"style="
                                          opacity: 0.90;
                              filter: alpha(opacity=90);"
                                       >
	<?php

	if(isset($_GET['action'])){
		include("_".$_GET['action'].".php");
		
	}
	else if(isset($_POST['action'])){
		if($_POST['action']=='editInfo'){
			include("_editInfo.php");			
		}
		else if($_POST['action']=='checkGarage'){
			include("_state.php");
			
		}
		else if($_POST['action']=='checkReserveGarage'||$_POST['action']=='confirmReserve'){

			include("_reserve.php");
		}
	}	
	else{	
		include("_home.php");
	}
	?>
    </div> <!-- /container -->

	
 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="//assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/garage/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!--<script src="//assets/js/ie10-viewport-bug-workaround.js"></script>-->
  </body>

</html>
