<?php
if(isset($_GET['reserve_id'])){
	
			if(mysqli_query($dbconnect,"DELETE FROM reservations WHERE reserve_id=".$_GET['reserve_id'])){
			echo "<h3>Successfully delete reservation!</h3>";

			$user = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM users WHERE user_id=".$_SESSION['user_id'] ));
			if($user['phoneNum']!=NULL){
				ini_set("SMTP", "ssl:smtp.gmail.com");
				ini_set("smtp_port", "465");
				$to       = $user['phoneNum'].'@tmomail.net';
				$subject  = 'Reservation Deleted';
				$message  = 'You have successfully deleted a reservation';
				$headers  = 'From: superlot14@gmail.com' . "\r\n" .
							'MIME-Version: 1.0' . "\r\n" .
							'Content-type: text/html; charset=utf-8';
				if(mail($to, $subject, $message, $headers))
					echo "Email sent";
				else
					echo "Email sending failed";
				
			}
		}
		else{
			echo "<h2>Failed to delete reservation !</h2>";		
			
		}
	
	
}
	else{
		echo "<h2>reserve id not provided!</h2>";
		
	}


?>