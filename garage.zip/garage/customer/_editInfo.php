<?php
if(isset($_POST['action'])&&($_POST['action']=='editInfo')){
	if(isset($_POST['username'])){
		if($_POST['password'] != $_POST['confirmpassword']){
			echo"<h2>Two password does not match!</h2>";
		}
		else{
			$plateNumCheck=mysqli_query($dbconnect,"SELECT * FROM user_account WHERE plateNum='".$_POST['plateNum']."'");
			if(mysqli_fetch_assoc($plateNumCheck)){
				echo "<h2>This Licence Plate is already registered</h2>";
			}
			else{
				$sql="Update users SET firstName='".$_POST['firstName']."',lastName='".$_POST['lastName'].", password='".$_POST['password']."',plateNume='".$_POST['plateNum']."',phoneNum='".$_POST['phoneNum']."' WHERE user_id=".$_SESSION['user_id'];
				if(mysqli_query($dbconnect,$sql)){
					echo"<h2>successfully updated user information</h2>";				
					}
				else{
					echo "<h2>failed to update user information</h2>";
				} 
			}       
		}
	}

	
}
else{	
	$user = mysqli_fetch_assoc(mysqli_query($dbconnect,"SELECT * FROM users WHERE user_id=".$_SESSION['user_id']));
	 
?>
<h3>Update Account Information</h3>
<form class="form" action="/garage/index.php" method="post" >

      <input hidden name="action" value = 'editInfo'/>	   
 <div class="form-group">
    <label for="firstName">First Name</label>
          <input type="text"  name="firstName" id="firstName" value = '<?php
			
			echo $user['firstName'];
		  
		  ?>'required />
 </div>
<div class="form-group">
		<label for="lastName">Last Name</label>
        <input type="text"  name="lastName" id="lastName" value = '<?php
			
			echo $user['lastName'];
		  
		  ?>'required />
 </div>

<div class="form-group">
    <label for="password">Password</label>
          <input type="text" name="password" id="password" value = '<?php
			
			echo $user['password'];
		  
		  ?>'required />
 </div>
<div class="form-group">
    <label for="plateNum">Plate Number</label>
          <input type="text"  style="text-transform:uppercase" maxlength='6'  name="plateNum" id="plateNum" value = '<?php
			
			echo $user['plateNum'];
		  
		  ?>'required />
 </div>
 <div class="form-group">
    <label for="phoneNum">Phone Number</label>
          <input type="text"  name="phoneNum" id="phoneNum" value = '<?php
			
			echo $user['phoneNum'];
		  
		  ?>' required />
 </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

   
	<?php
}
	?>