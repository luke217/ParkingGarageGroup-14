<?php

$year = date("Y");
$month =date("m");
$day = date("d");

$billing = mysqli_fetch_assoc(mysqli_query($dbconnect,'SELECT billing FROM users WHERE user_id='.$_SESSION['user_id']))['billing'];

if(mysqli_query($dbconnect,'UPDATE incomes SET income = income+'.$billing.'  WHERE year='.$year.' AND month ='.$month.' AND day='.$day)){
	if(mysqli_query($dbconnect,'UPDATE users SET billing = 0 WHERE user_id='.$_SESSION['user_id'])){
		
		echo"<h2>Successfully Payed $".$billing."</h2>";
		
	}
	else{
		echo"<h2>ERROR: Unable to update user billing </h2>";
		
	}
	
	
}
else{
	echo"<h2>ERROR: Unable to update income </h2>";
	
}

?>